# জেমিনি কীবোর্ড (Android, Kotlin)

বাংলা (অভ্র / প্রভাত / জাতীয়) + English কীবোর্ড। Gemini দিয়ে সাজেশন, অটো-কারেকশন, লেখা তৈরি ও অনুবাদ।
সাথে ক্লিপবোর্ড, ভয়েস টাইপিং, ইমোজি ও ৯টি থিম।

## ফোন থেকে অনলাইনে বিল্ড (GitHub Actions)
১. github.com-এ অ্যাকাউন্ট খুলে নতুন repository বানান (Public বা Private, দুটোই চলবে)।
২. Add file → Upload files দিয়ে `GeminiKeyboard.zip` আপলোড করে Commit করুন (zip খুলবেন না)।
৩. Add file → Create new file। নামের ঘরে লিখুন `.github/workflows/build.yml`, ভেতরে `build.yml` ফাইলের লেখা পেস্ট করে Commit করুন।
৪. Actions ট্যাবে বিল্ড চলবে (৫-১০ মিনিট)। সবুজ টিক এলে ডান পাশের Releases থেকে `GeminiKeyboard.apk` নামিয়ে ইনস্টল করুন।
   (লাল ✗ এলে সেই রানে ঢুকে ত্রুটির লেখাটি আমাকে পাঠান।)

## কম্পিউটারে
Android Studio-তে `GeminiKeyboard` ফোল্ডার Open করুন, Gradle 8.7+ লাগবে।

## ফাইল
- `KeyboardService.kt` — IME লজিক, ভয়েস, ক্লিপবোর্ড, AI
- `KeyboardView.kt` — UI (টুলবার, কী, ইমোজি/ক্লিপ/AI প্যানেল)
- `Themes.kt`, `ClipStore.kt`, `Emojis.kt`, `Layouts.kt`, `AvroEngine.kt`, `GeminiClient.kt`, `MainActivity.kt`
