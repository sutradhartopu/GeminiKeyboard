package com.example.geminikeyboard

/**
 * সরল অভ্র-ধাঁচের ফোনেটিক রূপান্তর (ল্যাটিন → বাংলা)।
 * নিয়ম: সবচেয়ে লম্বা মিল আগে; ব্যঞ্জনের পরে ব্যঞ্জন এলে হসন্ত বসে (যুক্তবর্ণ);
 * ব্যঞ্জনের পরে স্বর এলে কার; 'o' ব্যঞ্জনের পরে কিছু বসায় না (যুক্তবর্ণ আটকায়)।
 * নিখুঁত অভ্র নয় — Gemini সাজেশন বাকি ভুল ঠিক করে দেয়।
 */
object AvroEngine {
    private enum class T { CONS, VOWEL, MARK }

    private class Tok(val bn: String, val kar: String, val type: T)

    private const val HASANTA = "\u09CD"

    private val table: List<Pair<String, Tok>> = buildList {
        fun c(k: String, v: String) = add(k to Tok(v, "", T.CONS))
        fun v(k: String, ind: String, kar: String) = add(k to Tok(ind, kar, T.VOWEL))
        fun m(k: String, v: String) = add(k to Tok(v, "", T.MARK))

        // ব্যঞ্জন
        c("chh", "ছ"); c("ch", "চ"); c("c", "চ")
        c("kh", "খ"); c("k", "ক"); c("q", "ক")
        c("gh", "ঘ"); c("g", "গ"); c("Ng", "ঙ")
        c("jh", "ঝ"); c("j", "জ"); c("NG", "ঞ")
        c("Th", "ঠ"); c("T", "ট"); c("Dh", "ঢ"); c("D", "ড"); c("N", "ণ")
        c("th", "থ"); c("t", "ত"); c("dh", "ধ"); c("d", "দ"); c("n", "ন")
        c("ph", "ফ"); c("p", "প"); c("f", "ফ")
        c("bh", "ভ"); c("b", "ব"); c("v", "ভ"); c("m", "ম")
        c("z", "য"); c("r", "র"); c("l", "ল")
        c("sh", "শ"); c("Sh", "ষ"); c("S", "শ"); c("s", "স"); c("h", "হ")
        c("Rh", "\u09DD"); c("R", "\u09DC"); c("y", "\u09DF")
        c("x", "ক্স")

        // স্বরবর্ণ (স্বতন্ত্র, কার)
        v("rri", "ঋ", "\u09C3")
        v("oi", "ঐ", "\u09C8"); v("ou", "ঔ", "\u09CC")
        v("ii", "ঈ", "\u09C0"); v("I", "ঈ", "\u09C0")
        v("uu", "ঊ", "\u09C2"); v("U", "ঊ", "\u09C2")
        v("aa", "আ", "\u09BE"); v("a", "আ", "\u09BE")
        v("i", "ই", "\u09BF"); v("u", "উ", "\u09C1")
        v("e", "এ", "\u09C7"); v("O", "ও", "\u09CB")
        v("o", "অ", "")

        // চিহ্ন
        m("ng", "ং")
    }.sortedByDescending { it.first.length }

    fun convert(src: String): String {
        val sb = StringBuilder()
        var i = 0
        var afterConsonant = false
        while (i < src.length) {
            val hit = table.firstOrNull { src.startsWith(it.first, i) }
            if (hit == null) {
                sb.append(src[i])
                afterConsonant = false
                i++
                continue
            }
            val tok = hit.second
            when (tok.type) {
                T.CONS -> {
                    if (afterConsonant) sb.append(HASANTA)
                    sb.append(tok.bn)
                    afterConsonant = true
                }
                T.VOWEL -> {
                    sb.append(if (afterConsonant) tok.kar else tok.bn)
                    afterConsonant = false
                }
                T.MARK -> {
                    sb.append(tok.bn)
                    afterConsonant = false
                }
            }
            i += hit.first.length
        }
        return sb.toString()
    }
}
