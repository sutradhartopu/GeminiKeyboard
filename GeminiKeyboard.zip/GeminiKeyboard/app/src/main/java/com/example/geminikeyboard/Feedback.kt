package com.example.geminikeyboard

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator

/** কী চাপার ভাইব্রেশন ও শব্দ (টোন)। */
class Feedback(context: Context) {
    private val ctx = context.applicationContext

    var vibrate = true
    var vibrateMs = 18

    /** 0 বন্ধ, 1 সিস্টেম ক্লিক, 2 বিপ */
    var soundMode = 0

    /** 0.0 .. 1.0 */
    var volume = 0.5f

    @Suppress("DEPRECATION")
    private val vib: Vibrator? = ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    private val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var tone: ToneGenerator? = null
    private var toneVol = -1

    /** kind: 0 সাধারণ, 1 স্পেস, 2 ডিলিট, 3 এন্টার */
    fun key(kind: Int = 0) {
        if (vibrate) buzz()
        when (soundMode) {
            1 -> click(kind)
            2 -> beep()
        }
    }

    @Suppress("DEPRECATION")
    fun buzz() {
        try {
            val ms = vibrateMs.toLong()
            if (Build.VERSION.SDK_INT >= 26) {
                vib?.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                vib?.vibrate(ms)
            }
        } catch (e: Exception) {
            // ডিভাইসে ভাইব্রেটর না থাকলে উপেক্ষা
        }
    }

    private fun click(kind: Int) {
        try {
            val fx = when (kind) {
                1 -> AudioManager.FX_KEYPRESS_SPACEBAR
                2 -> AudioManager.FX_KEYPRESS_DELETE
                3 -> AudioManager.FX_KEYPRESS_RETURN
                else -> AudioManager.FX_KEYPRESS_STANDARD
            }
            am.playSoundEffect(fx, volume)
        } catch (e: Exception) {
        }
    }

    private fun beep() {
        try {
            val v = (volume * 100).toInt().coerceIn(1, 100)
            if (tone == null || toneVol != v) {
                tone?.release()
                tone = ToneGenerator(AudioManager.STREAM_SYSTEM, v)
                toneVol = v
            }
            tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 30)
        } catch (e: Exception) {
        }
    }
}
