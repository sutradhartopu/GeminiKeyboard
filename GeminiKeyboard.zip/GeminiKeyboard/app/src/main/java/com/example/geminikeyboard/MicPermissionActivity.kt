package com.example.geminikeyboard

import android.Manifest
import android.app.Activity
import android.os.Bundle

/** কীবোর্ড সার্ভিস নিজে অনুমতি চাইতে পারে না, তাই এই স্বচ্ছ অ্যাক্টিভিটি মাইক্রোফোনের অনুমতি চায়। */
class MicPermissionActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        finish()
    }
}
