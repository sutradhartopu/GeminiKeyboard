package com.example.geminikeyboard

/**
 * কীবোর্ড লেআউট ডেটা। প্রতিটি কী = (সাধারণ, শিফট/লং-প্রেস)।
 *
 * - english / অভ্র: QWERTY (অভ্র মোডে ল্যাটিন অক্ষর AvroEngine বাংলায় বদলায়)
 * - জাতীয়: সাধারণ জাতীয় কীবোর্ড বিন্যাস (স্ক্রিনশট মিলিয়ে করা)
 * - প্রভাত: অনুমানভিত্তিক — অফিসিয়াল ম্যাপ মিলিয়ে নিন; ভিন্ন হলে শুধু probhat টেবিল বদলান
 */
object Layouts {
    data class K(val n: String, val s: String)

    /** "সাধারণ শিফট" জোড়া স্পেস দিয়ে আলাদা */
    private fun r(vararg pairs: String): List<K> = pairs.map { p ->
        val parts = p.split(" ")
        K(parts[0], parts.getOrElse(1) { parts[0] })
    }

    val english: List<List<K>> = listOf("qwertyuiop", "asdfghjkl", "zxcvbnm").map { row ->
        row.map { K(it.toString(), it.uppercaseChar().toString()) }
    }

    val jatiya: List<List<K>> = listOf(
        r(
            "ঙ ং", "য য়", "ড ঢ", "প ফ", "ট ঠ",
            "চ ছ", "জ ঝ", "হ ঞ", "গ ঘ", "ড় ঢ়"
        ),
        r(
            "ৈ ঐ", "ু উ", "ি ই", "ব ভ", "্ ্",
            "া আ", "ক খ", "ত ৎ", "দ ধ"
        ),
        r(
            "ঁ ঃ", "ো ও", "ে এ", "র ল",
            "ন ণ", "স ষ", "ম শ"
        )
    )

    val probhat: List<List<K>> = listOf(
        r(
            "ঙ ঞ", "ও ঔ", "ে এ", "র ড়", "ত থ",
            "য় য", "ু উ", "ি ই", "ো অ", "প ফ"
        ),
        r(
            "া আ", "স শ", "দ ধ", "ী ঈ", "গ ঘ",
            "হ ঃ", "জ ঝ", "ক খ", "ল ং"
        ),
        r(
            "ট ঠ", "ড ঢ", "চ ছ", "ূ ঊ",
            "ব ভ", "ন ণ", "ম ঁ"
        )
    )

    const val BN_DIGITS = "১২৩৪৫৬৭৮৯০"
    const val EN_DIGITS = "1234567890"

    /** চিহ্নের পাতা: (দেখানো, লেখা) */
    val symbols: List<List<Pair<String, String>>> = listOf(
        listOf("@", "#", "$", "%", "&", "-", "+", "(", ")", "/"),
        listOf("*", "\"", "'", ":", ";", "!", "?", "_", "="),
        listOf("~", "<", ">", "[", "]", "{", "}")
    ).map { row -> row.map { it to it } }

    /** স্বরবর্ণ, চিহ্ন ও কারের পাতা (বাংলা মোডে); কার/চিহ্নের আগে ◌ নিজে থেকে বসে */
    val vowels: List<List<Pair<String, String>>> = listOf(
        listOf("অ", "আ", "ই", "ঈ", "উ", "ঊ", "ঋ", "এ", "ঐ", "ও").map { it to it },
        listOf("ঔ", "ং", "ঃ", "ঁ", "ৎ", "৳", "ো", "ৌ", "্").map { it to it },
        listOf("া", "ি", "ী", "ু", "ূ", "ৃ", "ে", "ৈ").map { it to it }
    )

    /** কার/চিহ্ন একা দেখালে আগে ◌ বসায়, যাতে কী-র লেখা বোঝা যায় */
    fun shown(t: String): String {
        if (t.isEmpty()) return t
        val ty = Character.getType(t[0])
        return if (ty == Character.NON_SPACING_MARK.toInt() || ty == Character.COMBINING_SPACING_MARK.toInt())
            "◌$t" else t
    }
}
