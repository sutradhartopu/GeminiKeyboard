package com.example.geminikeyboard

/**
 * কীবোর্ড লেআউট ডেটা। প্রতিটি কী = (সাধারণ, শিফট)।
 *
 * - english / অভ্র: QWERTY (অভ্র মোডে টাইপ করা ল্যাটিন অক্ষর AvroEngine বাংলায় বদলায়)
 * - জাতীয় (বিজয়-ধাঁচের): নিচের jatiya টেবিল
 * - প্রভাত: নিচের probhat টেবিল — এটি আমার মনে থাকা ফোনেটিক-অবস্থানভিত্তিক বিন্যাস, অফিসিয়াল
 *   প্রভাত ম্যাপের সাথে মিলিয়ে নিন; ভিন্ন হলে শুধু এই টেবিলের লাইনগুলো বদলালেই হবে।
 */
object Layouts {
    data class K(val n: String, val s: String)

    /** "সাধারণ শিফট" জোড়া স্পেস দিয়ে আলাদা */
    private fun r(vararg pairs: String): List<K> = pairs.map { p ->
        val parts = p.split(" ")
        K(parts[0], parts.getOrElse(1) { parts[0] })
    }

    val english: List<List<K>> = listOf("qwertyuiop", "asdfghjkl", "zxcvbnm").map { row ->
        row.map { K(it.toString(), it.uppercaseChar().toString()) }
    }

    val jatiya: List<List<K>> = listOf(
        r(
            "\u0999 \u0982", "\u09AF \u09DF", "\u09A1 \u09A2", "\u09AA \u09AB", "\u099F \u09A0",
            "\u099A \u099B", "\u099C \u099D", "\u09B9 \u099E", "\u0997 \u0998", "\u09DC \u09DD"
        ),
        r(
            "\u09C3 \u09B0\u09CD", "\u09C1 \u09C2", "\u09BF \u09C0", "\u09BE \u0985", "\u09CD \u0964",
            "\u09AC \u09AD", "\u0995 \u0996", "\u09A4 \u09A5", "\u09A6 \u09A7"
        ),
        r(
            "\u09CD\u09B0 \u09CD\u09AF", "\u0993 \u09D7", "\u09C7 \u09C8", "\u09B0 \u09B2",
            "\u09A8 \u09B8", "\u09B8 \u09B7", "\u09AE \u09B6"
        )
    )

    val probhat: List<List<K>> = listOf(
        r(
            "\u0999 \u099E", "\u0993 \u0994", "\u09C7 \u098F", "\u09B0 \u09DC", "\u09A4 \u09A5",
            "\u09DF \u09AF", "\u09C1 \u0989", "\u09BF \u0987", "\u09CB \u0985", "\u09AA \u09AB"
        ),
        r(
            "\u09BE \u0986", "\u09B8 \u09B6", "\u09A6 \u09A7", "\u09C0 \u0988", "\u0997 \u0998",
            "\u09B9 \u0983", "\u099C \u099D", "\u0995 \u0996", "\u09B2 \u0982"
        ),
        r(
            "\u099F \u09A0", "\u09A1 \u09A2", "\u099A \u099B", "\u09C2 \u098A",
            "\u09AC \u09AD", "\u09A8 \u09A3", "\u09AE \u0981"
        )
    )

    const val BN_DIGITS = "১২৩৪৫৬৭৮৯০"
    const val EN_DIGITS = "1234567890"

    /** চিহ্নের পাতা: (দেখানো, লেখা) */
    val symbols: List<List<Pair<String, String>>> = listOf(
        listOf("@", "#", "$", "%", "&", "-", "+", "(", ")", "/"),
        listOf("*", "\"", "'", ":", ";", "!", "?", "_", "="),
        listOf("~", "<", ">", "[", "]", "{", "}")
    ).map { row -> row.map { it to it } }

    /** স্বরবর্ণ, চিহ্ন ও কারের পাতা (বাংলা মোডে) */
    val vowels: List<List<Pair<String, String>>> = listOf(
        listOf("অ", "আ", "ই", "ঈ", "উ", "ঊ", "ঋ", "এ", "ঐ", "ও").map { it to it },
        listOf(
            "ঔ" to "ঔ", "ং" to "ং", "ঃ" to "ঃ",
            "\u25CC\u0981" to "\u0981", "ৎ" to "ৎ", "৳" to "৳",
            "\u25CC\u09D7" to "\u09D7", "\u25CC\u09BC" to "\u09BC", "\u25CC\u09CD" to "\u09CD"
        ),
        listOf("\u09BE", "\u09BF", "\u09C0", "\u09C1", "\u09C2", "\u09C3", "\u09C7").map { "\u25CC$it" to it }
    )
}
