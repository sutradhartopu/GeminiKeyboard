package com.example.geminikeyboard

import android.content.Context

/**
 * অফলাইন শব্দভান্ডার (assets/words_bn.txt, words_en.txt — ব্যবহারের ঘনত্ব অনুযায়ী সাজানো)।
 * ইন্টারনেট ছাড়াই, তাৎক্ষণিক প্রিফিক্স-সাজেশন দেয়।
 * ডেটার উৎস: wordfreq প্রকল্প (CC BY-SA 4.0)।
 */
object Dictionary {
    private class Index(words: List<String>) {
        val sorted: Array<String>
        val rank: IntArray

        init {
            val order = words.indices.sortedBy { words[it] }
            sorted = Array(order.size) { words[order[it]] }
            rank = IntArray(order.size) { order[it] }
        }

        private fun lower(prefix: String): Int {
            var lo = 0
            var hi = sorted.size
            while (lo < hi) {
                val mid = (lo + hi) ushr 1
                if (sorted[mid] < prefix) lo = mid + 1 else hi = mid
            }
            return lo
        }

        /** prefix দিয়ে শুরু, prefix-এর চেয়ে বড়, সবচেয়ে প্রচলিত [limit]টি শব্দ */
        fun top(prefix: String, limit: Int): List<String> {
            val ranks = IntArray(limit) { Int.MAX_VALUE }
            val ws = arrayOfNulls<String>(limit)
            var i = lower(prefix)
            while (i < sorted.size && sorted[i].startsWith(prefix)) {
                val w = sorted[i]
                if (w.length > prefix.length) {
                    val rk = rank[i]
                    var pos = limit
                    while (pos > 0 && rk < ranks[pos - 1]) pos--
                    if (pos < limit) {
                        for (j in limit - 1 downTo pos + 1) {
                            ranks[j] = ranks[j - 1]
                            ws[j] = ws[j - 1]
                        }
                        ranks[pos] = rk
                        ws[pos] = w
                    }
                }
                i++
            }
            return ws.filterNotNull()
        }
    }

    @Volatile private var bn: Index? = null
    @Volatile private var en: Index? = null
    @Volatile private var user: List<String> = emptyList()
    @Volatile private var loading = false

    /** ব্যাকগ্রাউন্ডে একবার লোড হয় */
    fun load(context: Context) {
        if (loading || (bn != null && en != null)) return
        loading = true
        val app = context.applicationContext
        Thread {
            try {
                bn = Index(read(app, "words_bn.txt"))
                en = Index(read(app, "words_en.txt"))
            } catch (e: Exception) {
                // শব্দভান্ডার ছাড়াও কীবোর্ড চলবে
            }
        }.start()
    }

    private fun read(c: Context, name: String): List<String> =
        c.assets.open(name).bufferedReader(Charsets.UTF_8).useLines { seq ->
            seq.map { it.trim() }.filter { it.isNotEmpty() }.toList()
        }

    fun setUserWords(words: List<String>) {
        user = words
    }

    /** [prefix]-এর সম্ভাব্য সম্পূর্ণ শব্দ; বাংলা বা ইংরেজি নিজে চিনে নেয় */
    fun suggest(prefix: String, limit: Int = 3): List<String> {
        if (prefix.isEmpty()) return emptyList()
        val bangla = prefix.any { it in 'ঀ'..'৿' }
        val out = ArrayList<String>(limit)

        // নিজের শব্দ আগে (সর্বোচ্চ ১টি)
        val pl = if (bangla) prefix else prefix.lowercase()
        user.firstOrNull { u ->
            val ul = if (bangla) u else u.lowercase()
            ul.startsWith(pl) && ul.length > pl.length
        }?.let { out.add(it) }

        val idx = if (bangla) bn else en
        if (idx != null) {
            if (bangla) {
                out.addAll(idx.top(prefix, limit))
            } else {
                val cap = prefix[0].isUpperCase()
                idx.top(pl, limit).forEach { out.add(if (cap) it.replaceFirstChar { c -> c.uppercaseChar() } else it) }
            }
        }
        return out.distinct().take(limit)
    }
}
