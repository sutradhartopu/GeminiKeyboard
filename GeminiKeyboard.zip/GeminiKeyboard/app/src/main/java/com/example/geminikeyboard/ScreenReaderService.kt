package com.example.geminikeyboard

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * শুধু ব্যবহারকারী কীবোর্ডের "স্ক্রিন অনুবাদ / উত্তর সাজেস্ট / চ্যাটে স্ক্রিন যোগ" বাটন চাপলে
 * বর্তমান স্ক্রিনের দৃশ্যমান লেখা পড়ে। পাসওয়ার্ড ও টাইপিং-ফিল্ডের লেখা বাদ যায়।
 * ইভেন্ট শোনা বা কিছু জমানো হয় না।
 */
class ScreenReaderService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    /** স্ক্রিনের লেখা, উপর থেকে নিচে; না পেলে null */
    fun readScreen(): String? {
        val root = rootInActiveWindow ?: return null
        val sb = StringBuilder()
        walk(root, sb, 0)
        val s = sb.toString().trim()
        return if (s.isEmpty()) null else s.take(MAX_CHARS)
    }

    private fun walk(node: AccessibilityNodeInfo?, sb: StringBuilder, depth: Int) {
        if (node == null || depth > 40 || sb.length > MAX_CHARS) return
        if (!node.isVisibleToUser || node.isPassword) return
        val t = node.text?.toString()?.trim()
        if (!t.isNullOrEmpty() && !node.isEditable) {
            if (sb.isNotEmpty()) sb.append('\n')
            sb.append(t)
        }
        for (i in 0 until node.childCount) walk(node.getChild(i), sb, depth + 1)
    }

    companion object {
        @Volatile
        var instance: ScreenReaderService? = null
        private const val MAX_CHARS = 8000
    }
}
