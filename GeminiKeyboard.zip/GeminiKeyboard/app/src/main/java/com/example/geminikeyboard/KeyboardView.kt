package com.example.geminikeyboard

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * কোড দিয়ে আঁকা কীবোর্ড UI: টুলবার (ইমোজি/ক্লিপবোর্ড/AI/ভয়েস/থিম/সেটিংস)
 * + সাজেশন স্ট্রিপ + কী-সারি বা প্যানেল।
 */
class KeyboardView(context: Context, private val l: Listener) : LinearLayout(context) {

    interface Listener {
        fun onChar(text: String)
        fun onBackspace()
        fun onSpace()
        fun onEnter()
        fun onChip(text: String)
        fun onLangToggle()
        fun onEmoji(e: String)
        fun recentEmojis(): List<String>
        fun onVoice()
        fun onClipPaste(text: String)
        fun onClipPin(text: String)
        fun onClipDelete(text: String)
        fun onClipSaveSelection()
        fun onClipClear()
        /** action: write | fix | shorter | longer | formal | friendly | translate | undo */
        fun onAi(action: String, arg: String)
        fun onThemeNext()
        fun onOpenSettings()
    }

    enum class Mode { EN, BN }
    private enum class Page { LETTERS, SYMBOLS, VOWELS, EMOJI, CLIP, AI }

    var mode = Mode.EN
    var bnLayout = "avro"
    var haptics = true
    var theme: Theme = Themes.all[0]
    var translateTo = "English"

    var busy = false
        set(v) {
            field = v
            status.text = if (v) "•••" else ""
        }

    var listening = false
        set(v) {
            if (field != v) {
                field = v
                if (built) refresh()
            }
        }

    private var clips: List<Clip> = emptyList()
    private var page = Page.LETTERS
    private var shift = 0 // 0 বন্ধ, 1 একবার, 2 ক্যাপস
    private var lastShiftTap = 0L
    private var emojiCat = 1
    private var built = false
    private var lastChips: List<String> = emptyList()
    private var lastHighlight = -1

    private val rows = LinearLayout(context)
    private var chips: List<TextView> = emptyList()
    private var status = TextView(context)

    init {
        orientation = LinearLayout.VERTICAL
        rows.orientation = LinearLayout.VERTICAL
        refresh()
        built = true
    }

    // ---------- বাইরের API ----------

    fun applyTheme(t: Theme) {
        theme = t
        refresh()
    }

    fun setClips(list: List<Clip>) {
        clips = list
        if (page == Page.CLIP) render()
    }

    fun setChips(list: List<String>, highlight: Int) {
        lastChips = list
        lastHighlight = highlight
        chips.forEachIndexed { i, tv ->
            val t = list.getOrElse(i) { "" }
            tv.text = t
            val hint = t == HINT
            tv.setTextColor(if (i == highlight || hint) theme.accent else theme.text)
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, if (hint) 13f else 17f)
            tv.setTypeface(null, if (i == highlight) Typeface.BOLD else Typeface.NORMAL)
        }
    }

    /** পুরো UI নতুন করে আঁকে (থিম/ভাষা/প্যানেল বদলালে) */
    fun refresh() {
        removeAllViews()
        setBackgroundColor(theme.bg)
        setPadding(dp(4), 0, dp(4), dp(6))
        addView(buildToolbar(), lp(MATCH, dp(38)))
        addView(buildStrip(), lp(MATCH, dp(44)))
        addView(rows, lp(MATCH, WRAP))
        render()
        setChips(lastChips, lastHighlight)
    }

    // ---------- টুলবার ও সাজেশন স্ট্রিপ ----------

    private fun togglePage(p: Page) {
        page = if (page == p) Page.LETTERS else p
        refresh()
    }

    private fun buildToolbar(): LinearLayout {
        val bar = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        fun tool(label: String, on: Boolean, color: Int = theme.text, onTap: () -> Unit) {
            val tv = TextView(context).apply {
                text = label
                gravity = Gravity.CENTER
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
                setTextColor(if (on) theme.onAccent else color)
                background = ripple(if (on) theme.accent else 0x00000000, 10f)
                setOnClickListener {
                    haptic()
                    onTap()
                }
            }
            bar.addView(tv, lp(0, dp(34), 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
        }
        tool("😊", page == Page.EMOJI) { togglePage(Page.EMOJI) }
        tool("📋", page == Page.CLIP) { togglePage(Page.CLIP) }
        tool("✦", page == Page.AI, theme.accent) { togglePage(Page.AI) }
        tool(if (listening) "⏹" else "🎤", listening) { l.onVoice() }
        tool("🎨", false) { l.onThemeNext() }
        tool("⚙", false, theme.sub) { l.onOpenSettings() }
        return bar
    }

    private fun buildStrip(): LinearLayout {
        val strip = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val list = List(3) { TextView(context) }
        list.forEachIndexed { i, tv ->
            tv.gravity = Gravity.CENTER
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            tv.setTextColor(theme.text)
            tv.maxLines = 1
            tv.ellipsize = TextUtils.TruncateAt.END
            tv.setPadding(dp(6), 0, dp(6), 0)
            tv.background = ripple(0x00000000, 10f)
            tv.setOnClickListener {
                val t = tv.text.toString()
                if (t.isNotEmpty()) {
                    haptic()
                    l.onChip(t)
                }
            }
            strip.addView(tv, lp(0, dp(42), 1f))
            if (i < list.size - 1) {
                val d = View(context)
                d.setBackgroundColor(theme.sub)
                d.alpha = 0.35f
                strip.addView(d, lp(dp(1), dp(20)))
            }
        }
        chips = list
        status = TextView(context).apply {
            setTextColor(theme.accent)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            gravity = Gravity.CENTER
        }
        strip.addView(status, lp(dp(30), dp(42)))
        return strip
    }

    // ---------- কী-সারি ও প্যানেল ----------

    private fun render() {
        rows.removeAllViews()
        val bn = mode == Mode.BN
        when (page) {
            Page.LETTERS -> letterRows(bn)
            Page.SYMBOLS -> {
                rows.addView(digitRow(bn))
                pagedRows(Layouts.symbols)
            }
            Page.VOWELS -> {
                rows.addView(digitRow(bn))
                pagedRows(Layouts.vowels)
            }
            Page.EMOJI -> rows.addView(emojiPanel())
            Page.CLIP -> rows.addView(clipPanel())
            Page.AI -> rows.addView(aiPanel())
        }
        rows.addView(bottomRow(bn))
    }

    private fun letterRows(bn: Boolean) {
        val phonetic = bn && bnLayout == "avro"
        val letters: List<List<Layouts.K>> = when {
            !bn || phonetic -> Layouts.english
            bnLayout == "jatiya" -> Layouts.jatiya
            else -> Layouts.probhat
        }
        val hints = bn && !phonetic
        rows.addView(digitRow(bn))
        rows.addView(row().also { r -> letters[0].forEach { r.addView(letterKey(it, hints)) } })
        rows.addView(row().also { r ->
            r.addView(spacer(0.5f))
            letters[1].forEach { r.addView(letterKey(it, hints)) }
            r.addView(spacer(0.5f))
        })
        rows.addView(row().also { r ->
            r.addView(shiftKey())
            letters[2].forEach { r.addView(letterKey(it, hints)) }
            r.addView(backspaceKey())
        })
    }

    private fun digitRow(bn: Boolean): LinearLayout = row().also { r ->
        val digits = if (bn) Layouts.BN_DIGITS else Layouts.EN_DIGITS
        digits.forEachIndexed { i, d ->
            val latin = Layouts.EN_DIGITS[i].toString()
            r.addView(
                key(d.toString(), 1f, theme.key, size = 17f, h = 40,
                    hint = if (bn) latin else null,
                    onLong = if (bn) ({ l.onChar(latin) }) else null) { l.onChar(d.toString()) }
            )
        }
    }

    private fun bottomRow(bn: Boolean): LinearLayout = row().also { r ->
        val panel = page == Page.EMOJI || page == Page.CLIP || page == Page.AI
        if (panel) {
            r.addView(key("ABC", 1.5f, theme.special, size = 14f) {
                page = Page.LETTERS
                refresh()
            })
            r.addView(key(spaceLabel(), 5f, theme.key, fg = theme.sub, size = 13f) { l.onSpace() })
            r.addView(backspaceKey())
            r.addView(key("↵", 1.5f, theme.accent, fg = theme.onAccent, size = 22f) { l.onEnter() })
            return@also
        }
        val toggleLabel = when (page) {
            Page.SYMBOLS -> if (bn) "অআ" else "ABC"
            Page.VOWELS -> "ABC"
            else -> "?123"
        }
        r.addView(key(toggleLabel, 1.3f, theme.special, size = 14f) {
            page = when (page) {
                Page.LETTERS -> Page.SYMBOLS
                Page.SYMBOLS -> if (bn) Page.VOWELS else Page.LETTERS
                else -> Page.LETTERS
            }
            render()
        })
        r.addView(key(if (bn) "বাং" else "EN", 1.2f, theme.special, size = 14f) {
            page = Page.LETTERS
            shift = 0
            l.onLangToggle()
        })
        r.addView(key(",", 1f, theme.special, size = 20f) { l.onChar(",") })
        r.addView(key(spaceLabel(), 3.6f, theme.key, fg = theme.sub, size = 13f) { l.onSpace() })
        r.addView(key(if (bn) "।" else ".", 1f, theme.special, size = 20f) { l.onChar(if (bn) "।" else ".") })
        r.addView(key("↵", 1.3f, theme.accent, fg = theme.onAccent, size = 22f) { l.onEnter() })
    }

    private fun spaceLabel(): String = if (mode == Mode.EN) "English" else when (bnLayout) {
        "jatiya" -> "বাংলা · জাতীয়"
        "probhat" -> "বাংলা · প্রভাত"
        else -> "বাংলা · অভ্র"
    }

    private fun pagedRows(data: List<List<Pair<String, String>>>) {
        rows.addView(row().also { r ->
            data[0].forEach { (label, text) -> r.addView(key(Layouts.shown(label), 1f, theme.key) { l.onChar(text) }) }
        })
        rows.addView(row().also { r ->
            r.addView(spacer(0.5f))
            data[1].forEach { (label, text) -> r.addView(key(Layouts.shown(label), 1f, theme.key) { l.onChar(text) }) }
            r.addView(spacer(0.5f))
        })
        rows.addView(row().also { r ->
            r.addView(spacer(1f))
            data[2].forEach { (label, text) -> r.addView(key(Layouts.shown(label), 1f, theme.key) { l.onChar(text) }) }
            r.addView(backspaceKey())
        })
    }

    private fun letterKey(k: Layouts.K, hints: Boolean): FrameLayout {
        val t = if (shift > 0) k.s else k.n
        val canHint = hints && k.s != k.n
        return key(
            Layouts.shown(t), 1f, theme.key,
            hint = if (canHint && shift == 0) Layouts.shown(k.s) else null,
            onLong = if (canHint) ({ l.onChar(k.s) }) else null
        ) {
            l.onChar(t)
            if (shift == 1) {
                shift = 0
                render()
            }
        }
    }

    private fun shiftKey(): FrameLayout {
        val active = shift > 0
        val label = if (shift == 2) "⇪" else "⇧"
        return key(
            label, 1.5f, if (active) theme.accent else theme.special,
            fg = if (active) theme.onAccent else theme.text, size = 20f
        ) {
            val now = SystemClock.uptimeMillis()
            shift = when {
                now - lastShiftTap < 350 -> 2
                shift == 0 -> 1
                else -> 0
            }
            lastShiftTap = now
            render()
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun backspaceKey(): FrameLayout {
        val f = key("⌫", 1.5f, theme.special, size = 20f) { }
        f.setOnClickListener(null)
        val handler = Handler(Looper.getMainLooper())
        val repeater = object : Runnable {
            override fun run() {
                l.onBackspace()
                handler.postDelayed(this, 45)
            }
        }
        f.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.isPressed = true
                    haptic()
                    l.onBackspace()
                    handler.postDelayed(repeater, 380)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.isPressed = false
                    handler.removeCallbacks(repeater)
                }
            }
            true
        }
        return f
    }

    // ---------- ইমোজি প্যানেল ----------

    private fun emojiPanel(): View {
        val box = panelBox()
        val tabs = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        Emojis.cats.forEachIndexed { i, c ->
            val sel = i == emojiCat
            tabs.addView(
                TextView(context).apply {
                    text = c.icon
                    gravity = Gravity.CENTER
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
                    background = ripple(if (sel) theme.accent else 0x00000000, 10f)
                    alpha = if (sel) 1f else 0.85f
                    setOnClickListener {
                        haptic()
                        emojiCat = i
                        render()
                    }
                },
                lp(0, dp(34), 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) }
            )
        }
        box.addView(tabs, lp(MATCH, dp(38)))

        val items = if (emojiCat == 0) l.recentEmojis() else Emojis.cats[emojiCat].items
        val col = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        if (items.isEmpty()) {
            col.addView(note("এখনও কোনো সাম্প্রতিক ইমোজি নেই"))
        } else {
            items.chunked(8).forEach { chunk ->
                val r = row()
                chunk.forEach { e ->
                    r.addView(
                        TextView(context).apply {
                            text = e
                            gravity = Gravity.CENTER
                            setTextSize(TypedValue.COMPLEX_UNIT_SP, 24f)
                            background = ripple(0x00000000, 8f)
                            setOnClickListener {
                                haptic()
                                l.onEmoji(e)
                            }
                        },
                        lp(0, dp(44), 1f)
                    )
                }
                repeat(8 - chunk.size) { r.addView(spacer(1f)) }
                col.addView(r)
            }
        }
        val scroll = ScrollView(context)
        scroll.addView(col)
        box.addView(scroll, lp(MATCH, 0, 1f))
        return box
    }

    // ---------- ক্লিপবোর্ড প্যানেল ----------

    private fun clipPanel(): View {
        val box = panelBox()
        val top = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        top.addView(
            pill("＋ সিলেক্ট করা লেখা সেভ", theme.key, theme.text, 13f) { l.onClipSaveSelection() },
            lp(0, dp(34), 1f).apply { setMargins(dp(3), dp(2), dp(3), dp(2)) }
        )
        top.addView(
            pill("🗑 পুরোনো মুছুন", theme.key, theme.text, 13f) { l.onClipClear() },
            lp(0, dp(34), 1f).apply { setMargins(dp(3), dp(2), dp(3), dp(2)) }
        )
        box.addView(top, lp(MATCH, dp(38)))

        val col = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        if (clips.isEmpty()) {
            col.addView(note("কপি করা লেখা এখানে জমা হবে।\n📌 চাপলে লেখাটি সেভ থাকবে, নিজে মুছবে না।"))
        } else {
            clips.forEach { col.addView(clipRow(it)) }
        }
        val scroll = ScrollView(context)
        scroll.addView(col)
        box.addView(scroll, lp(MATCH, 0, 1f))
        return box
    }

    private fun clipRow(c: Clip): View {
        val r = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = ripple(theme.key, 10f)
            layoutParams = lp(MATCH, WRAP).apply { setMargins(dp(3), dp(3), dp(3), 0) }
            minimumHeight = dp(44)
        }
        r.addView(
            TextView(context).apply {
                text = c.text.replace("\n", " ")
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
                setTextColor(theme.text)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                setPadding(dp(10), dp(6), dp(6), dp(6))
                setOnClickListener {
                    haptic()
                    l.onClipPaste(c.text)
                }
            },
            lp(0, WRAP, 1f)
        )
        r.addView(
            TextView(context).apply {
                text = "📌"
                gravity = Gravity.CENTER
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                alpha = if (c.pinned) 1f else 0.3f
                setOnClickListener {
                    haptic()
                    l.onClipPin(c.text)
                }
            },
            lp(dp(40), dp(40))
        )
        r.addView(
            TextView(context).apply {
                text = "✕"
                gravity = Gravity.CENTER
                setTextColor(theme.sub)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                setOnClickListener {
                    haptic()
                    l.onClipDelete(c.text)
                }
            },
            lp(dp(40), dp(40))
        )
        return r
    }

    // ---------- AI প্যানেল ----------

    private fun aiPanel(): View {
        val box = panelBox()
        box.addView(
            note("ফিল্ডে লেখা বা প্রম্পট লিখুন (বা সিলেক্ট করুন), তারপর একটি বাটন চাপুন")
                .apply { setPadding(dp(6), dp(2), dp(6), 0) },
            lp(MATCH, WRAP)
        )

        fun addRow(items: List<Triple<String, Boolean, () -> Unit>>) {
            val r = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
            items.forEach { (label, primary, act) ->
                r.addView(
                    pill(
                        label,
                        if (primary) theme.accent else theme.key,
                        if (primary) theme.onAccent else theme.text,
                        14f, act
                    ),
                    lp(0, dp(38), 1f).apply { setMargins(dp(3), dp(4), dp(3), 0) }
                )
            }
            box.addView(r, lp(MATCH, WRAP))
        }
        addRow(
            listOf(
                Triple("✍ লিখে দাও", true, { l.onAi("write", "") }),
                Triple("✦ ঠিক করো", false, { l.onAi("fix", "") }),
                Triple("↩ আগেরটা", false, { l.onAi("undo", "") })
            )
        )
        addRow(
            listOf(
                Triple("✂ ছোট", false, { l.onAi("shorter", "") }),
                Triple("➕ বড়", false, { l.onAi("longer", "") }),
                Triple("👔 ফরমাল", false, { l.onAi("formal", "") }),
                Triple("😊 ঘরোয়া", false, { l.onAi("friendly", "") })
            )
        )

        box.addView(
            note("🌐 অনুবাদ — ভাষা বাছুন:").apply { setPadding(dp(6), dp(8), dp(6), 0) },
            lp(MATCH, WRAP)
        )
        val langRow = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        LANGS.forEach { (label, name) ->
            val sel = name == translateTo
            langRow.addView(
                pill(
                    label,
                    if (sel) theme.accent else theme.key,
                    if (sel) theme.onAccent else theme.text, 14f
                ) {
                    translateTo = name
                    l.onAi("translate", name)
                    render()
                },
                lp(WRAP, dp(38)).apply { setMargins(dp(3), dp(4), dp(3), 0) }
            )
        }
        val hs = HorizontalScrollView(context).apply { isHorizontalScrollBarEnabled = false }
        hs.addView(langRow)
        box.addView(hs, lp(MATCH, WRAP))
        return box
    }

    // ---------- সহায়ক ----------

    private fun panelBox(): LinearLayout = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        layoutParams = lp(MATCH, dp(PANEL_H))
    }

    private fun note(s: String) = TextView(context).apply {
        text = s
        setTextColor(theme.sub)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        setPadding(dp(8), dp(12), dp(8), dp(4))
    }

    private fun pill(label: String, fill: Int, fg: Int, size: Float = 14f, onTap: () -> Unit) =
        TextView(context).apply {
            text = label
            setTextColor(fg)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
            gravity = Gravity.CENTER
            maxLines = 1
            setPadding(dp(12), 0, dp(12), 0)
            background = ripple(fill, 18f)
            setOnClickListener {
                haptic()
                onTap()
            }
        }

    private fun row(): LinearLayout = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL
        layoutParams = lp(MATCH, WRAP)
    }

    private fun spacer(w: Float) = View(context).apply {
        layoutParams = lp(0, 1, w)
    }

    private fun key(
        label: String, weight: Float, fill: Int,
        fg: Int = theme.text, size: Float = 20f, h: Int = 46,
        hint: String? = null, onLong: (() -> Unit)? = null,
        onTap: () -> Unit
    ): FrameLayout {
        val f = FrameLayout(context)
        f.background = ripple(fill, 9f)
        f.layoutParams = lp(0, dp(h), weight).apply { setMargins(dp(3), dp(4), dp(3), 0) }
        val main = TextView(context).apply {
            text = label
            gravity = Gravity.CENTER
            setTextColor(fg)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
            maxLines = 1
            includeFontPadding = false
        }
        f.addView(main, FrameLayout.LayoutParams(MATCH, MATCH))
        if (hint != null) {
            val ht = TextView(context).apply {
                text = hint
                setTextColor(theme.sub)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
                includeFontPadding = false
            }
            f.addView(
                ht,
                FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.END).apply {
                    setMargins(0, dp(2), dp(5), 0)
                }
            )
        }
        f.setOnClickListener {
            haptic()
            onTap()
        }
        if (onLong != null) {
            f.setOnLongClickListener {
                haptic()
                onLong()
                true
            }
        }
        return f
    }

    private fun ripple(fill: Int, radiusDp: Float) = RippleDrawable(
        ColorStateList.valueOf(theme.ripple),
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(radiusDp.toInt()).toFloat()
        },
        null
    )

    private fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)

    private fun haptic() {
        if (haptics) performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
    }

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    companion object {
        const val HINT = "⚙ Gemini API কী দিন"
        private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
        private const val PANEL_H = 194

        /** (দেখানো নাম, Gemini-কে দেওয়া ভাষার নাম) */
        val LANGS = listOf(
            "English" to "English", "বাংলা" to "Bengali", "हिन्दी" to "Hindi",
            "العربية" to "Arabic", "اردو" to "Urdu", "Español" to "Spanish",
            "Français" to "French", "Deutsch" to "German", "日本語" to "Japanese",
            "한국어" to "Korean", "中文" to "Chinese", "Türkçe" to "Turkish",
            "Русский" to "Russian", "Indonesia" to "Indonesian", "Melayu" to "Malay"
        )
    }
}
