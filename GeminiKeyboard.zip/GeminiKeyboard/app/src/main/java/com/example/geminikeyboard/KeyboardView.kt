package com.example.geminikeyboard

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView

/** কোড দিয়ে আঁকা কীবোর্ড UI: সাজেশন স্ট্রিপ + কী-সারি। ডার্ক/লাইট সিস্টেম থিম অনুসরণ করে। */
class KeyboardView(context: Context, private val l: Listener) : LinearLayout(context) {

    interface Listener {
        fun onChar(text: String)
        fun onBackspace()
        fun onSpace()
        fun onEnter()
        fun onChip(text: String)
        fun onFix()
        fun onLangToggle()
    }

    enum class Mode { EN, BN }
    private enum class Page { LETTERS, SYMBOLS, VOWELS }

    var mode = Mode.EN
    var bnLayout = "avro"
    var haptics = true
    var busy = false
        set(v) {
            field = v
            status.text = if (v) "•••" else ""
        }

    private var page = Page.LETTERS
    private var shift = 0 // 0 বন্ধ, 1 একবার, 2 ক্যাপস
    private var lastShiftTap = 0L

    // ---- রঙ ----
    private val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
        Configuration.UI_MODE_NIGHT_YES
    private val cBg = if (night) 0xFF14161B.toInt() else 0xFFE8EBF1.toInt()
    private val cKey = if (night) 0xFF262A33.toInt() else 0xFFFFFFFF.toInt()
    private val cSpecial = if (night) 0xFF1D2027.toInt() else 0xFFCDD3DF.toInt()
    private val cAccent = if (night) 0xFF7C8CFF.toInt() else 0xFF4F5EE8.toInt()
    private val cText = if (night) 0xFFECEFF4.toInt() else 0xFF1B1E26.toInt()
    private val cSub = if (night) 0xFF8A93A6.toInt() else 0xFF6B7385.toInt()
    private val cRipple = if (night) 0x33FFFFFF else 0x22000000

    private val strip = LinearLayout(context)
    private val chips = List(3) { TextView(context) }
    private val status = TextView(context)
    private val rows = LinearLayout(context)

    init {
        orientation = VERTICAL
        setBackgroundColor(cBg)
        setPadding(dp(4), 0, dp(4), dp(6))
        buildStrip()
        rows.orientation = VERTICAL
        addView(
            rows,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        render()
    }

    // ---------- সাজেশন স্ট্রিপ ----------

    private fun buildStrip() {
        strip.orientation = HORIZONTAL
        strip.gravity = Gravity.CENTER_VERTICAL
        chips.forEachIndexed { i, tv ->
            tv.gravity = Gravity.CENTER
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            tv.setTextColor(cText)
            tv.maxLines = 1
            tv.ellipsize = TextUtils.TruncateAt.END
            tv.setPadding(dp(6), 0, dp(6), 0)
            tv.background = ripple(0x00000000, 10f)
            tv.setOnClickListener {
                val t = tv.text.toString()
                if (t.isNotEmpty()) {
                    haptic(); l.onChip(t)
                }
            }
            strip.addView(tv, LinearLayout.LayoutParams(0, dp(44), 1f))
            if (i < chips.size - 1) {
                val d = View(context)
                d.setBackgroundColor(cSub)
                d.alpha = 0.35f
                strip.addView(d, LinearLayout.LayoutParams(dp(1), dp(20)))
            }
        }
        status.setTextColor(cAccent)
        status.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        status.gravity = Gravity.CENTER
        strip.addView(status, LinearLayout.LayoutParams(dp(34), dp(44)))
        addView(strip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)))
    }

    fun setChips(list: List<String>, highlight: Int) {
        chips.forEachIndexed { i, tv ->
            val t = list.getOrElse(i) { "" }
            tv.text = t
            val hint = t == HINT
            tv.setTextColor(if (i == highlight || hint) cAccent else cText)
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, if (hint) 13f else 17f)
            tv.setTypeface(null, if (i == highlight) Typeface.BOLD else Typeface.NORMAL)
        }
    }

    // ---------- কী-সারি ----------

    fun render() {
        rows.removeAllViews()
        val bn = mode == Mode.BN
        val phonetic = bn && bnLayout == "avro"
        val letters: List<List<Layouts.K>> = when {
            !bn || phonetic -> Layouts.english
            bnLayout == "jatiya" -> Layouts.jatiya
            else -> Layouts.probhat
        }

        // নম্বর সারি
        val digits = if (bn) Layouts.BN_DIGITS else Layouts.EN_DIGITS
        rows.addView(row().also { r ->
            digits.forEach { d -> r.addView(key(d.toString(), 1f, cKey, size = 17f, h = 40) { l.onChar(d.toString()) }) }
        })

        when (page) {
            Page.LETTERS -> {
                rows.addView(row().also { r -> letters[0].forEach { r.addView(letterKey(it)) } })
                rows.addView(row().also { r ->
                    r.addView(spacer(0.5f))
                    letters[1].forEach { r.addView(letterKey(it)) }
                    r.addView(spacer(0.5f))
                })
                rows.addView(row().also { r ->
                    r.addView(shiftKey())
                    letters[2].forEach { r.addView(letterKey(it)) }
                    r.addView(backspaceKey())
                })
            }
            Page.SYMBOLS -> pagedRows(Layouts.symbols)
            Page.VOWELS -> pagedRows(Layouts.vowels)
        }

        // নিচের সারি
        rows.addView(row().also { r ->
            val toggleLabel = when (page) {
                Page.LETTERS -> "?123"
                Page.SYMBOLS -> if (bn) "অআ" else "ABC"
                Page.VOWELS -> "ABC"
            }
            r.addView(key(toggleLabel, 1.3f, cSpecial, size = 14f) {
                page = when (page) {
                    Page.LETTERS -> Page.SYMBOLS
                    Page.SYMBOLS -> if (bn) Page.VOWELS else Page.LETTERS
                    Page.VOWELS -> Page.LETTERS
                }
                render()
            })
            r.addView(key(if (bn) "বাং" else "EN", 1.2f, cSpecial, size = 14f) {
                page = Page.LETTERS
                shift = 0
                l.onLangToggle()
            })
            r.addView(key("✦", 1.1f, cSpecial, fg = cAccent, size = 20f) { l.onFix() })
            r.addView(key(spaceLabel(), 4f, cKey, fg = cSub, size = 13f) { l.onSpace() })
            r.addView(key(if (bn) "।" else ".", 1f, cSpecial, size = 20f) { l.onChar(if (bn) "।" else ".") })
            r.addView(key("↵", 1.3f, cAccent, fg = 0xFFFFFFFF.toInt(), size = 22f) { l.onEnter() })
        })
    }

    private fun spaceLabel(): String = if (mode == Mode.EN) "English" else when (bnLayout) {
        "jatiya" -> "বাংলা · জাতীয়"
        "probhat" -> "বাংলা · প্রভাত"
        else -> "বাংলা · অভ্র"
    }

    private fun pagedRows(data: List<List<Pair<String, String>>>) {
        rows.addView(row().also { r ->
            data[0].forEach { (label, text) -> r.addView(key(label, 1f, cKey) { l.onChar(text) }) }
        })
        rows.addView(row().also { r ->
            r.addView(spacer(0.5f))
            data[1].forEach { (label, text) -> r.addView(key(label, 1f, cKey) { l.onChar(text) }) }
            r.addView(spacer(0.5f))
        })
        rows.addView(row().also { r ->
            r.addView(spacer(1f))
            data[2].forEach { (label, text) -> r.addView(key(label, 1f, cKey) { l.onChar(text) }) }
            r.addView(backspaceKey())
        })
    }

    private fun letterKey(k: Layouts.K): TextView {
        val t = if (shift > 0) k.s else k.n
        return key(t, 1f, cKey) {
            l.onChar(t)
            if (shift == 1) {
                shift = 0
                render()
            }
        }
    }

    private fun shiftKey(): TextView {
        val active = shift > 0
        val label = if (shift == 2) "⇪" else "⇧"
        return key(label, 1.5f, if (active) cAccent else cSpecial,
            fg = if (active) 0xFFFFFFFF.toInt() else cText, size = 20f) {
            val now = SystemClock.uptimeMillis()
            shift = when {
                now - lastShiftTap < 350 -> 2
                shift == 0 -> 1
                else -> 0
            }
            lastShiftTap = now
            render()
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun backspaceKey(): TextView {
        val tv = key("⌫", 1.5f, cSpecial, size = 20f) { }
        tv.setOnClickListener(null)
        val handler = Handler(Looper.getMainLooper())
        val repeater = object : Runnable {
            override fun run() {
                l.onBackspace()
                handler.postDelayed(this, 45)
            }
        }
        tv.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.isPressed = true
                    haptic()
                    l.onBackspace()
                    handler.postDelayed(repeater, 380)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.isPressed = false
                    handler.removeCallbacks(repeater)
                }
            }
            true
        }
        return tv
    }

    // ---------- সহায়ক ----------

    private fun row(): LinearLayout = LinearLayout(context).apply {
        orientation = HORIZONTAL
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
    }

    private fun spacer(w: Float) = View(context).apply {
        layoutParams = LinearLayout.LayoutParams(0, 1, w)
    }

    private fun key(
        label: String, weight: Float, fill: Int,
        fg: Int = cText, size: Float = 20f, h: Int = 48,
        onTap: () -> Unit
    ): TextView = TextView(context).apply {
        text = label
        gravity = Gravity.CENTER
        setTextColor(fg)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
        maxLines = 1
        background = ripple(fill, 9f)
        layoutParams = LinearLayout.LayoutParams(0, dp(h), weight).apply {
            setMargins(dp(3), dp(4), dp(3), dp(0))
        }
        setOnClickListener {
            haptic()
            onTap()
        }
    }

    private fun ripple(fill: Int, radiusDp: Float) = RippleDrawable(
        ColorStateList.valueOf(cRipple),
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(radiusDp.toInt()).toFloat()
        },
        null
    )

    private fun haptic() {
        if (haptics) performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
    }

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    companion object {
        const val HINT = "⚙ Gemini API কী দিন"
    }
}
