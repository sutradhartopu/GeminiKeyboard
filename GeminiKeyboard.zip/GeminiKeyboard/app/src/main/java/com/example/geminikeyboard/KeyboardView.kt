package com.example.geminikeyboard

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.abs

/**
 * কোড দিয়ে আঁকা কীবোর্ড UI।
 * টুলবার (ইমোজি/ক্লিপবোর্ড/AI/চ্যাট/স্ক্রিন অনুবাদ/ভয়েস/থিম/সেটিংস) + সাজেশন স্ট্রিপ + কী-সারি বা প্যানেল।
 * শিফট বদলালে শুধু লেখা বদলায় (পুরো UI নতুন করে আঁকা হয় না), তাই টাইপিং স্মুথ থাকে।
 */
class KeyboardView(context: Context, private val l: Listener) : LinearLayout(context) {

    interface Listener {
        fun onChar(text: String)
        fun onBackspace()
        fun onSpace()
        fun onEnter()
        fun onChip(text: String)
        /** স্পেসবারে সোয়াইপ বা ভাষা-কী চাপলে: dir = +1 / -1 */
        fun onSwitchLayout(dir: Int)
        fun onEmoji(e: String)
        fun recentEmojis(): List<String>
        fun onVoice()
        fun onClipPaste(text: String)
        fun onClipPin(text: String)
        fun onClipDelete(text: String)
        fun onClipSaveSelection()
        fun onClipClear()
        /** action: write | fix | shorter | longer | formal | friendly | translate | undo */
        fun onAi(action: String, arg: String)
        fun onThemeNext()
        fun onOpenSettings()
        fun onChatMode(on: Boolean)
        fun onChatSend()
        fun onChatClear()
        fun onChatInsert(text: String)
        /** স্ক্রিনের লেখা পড়ে পরের প্রশ্নের সাথে Gemini-কে দেওয়ার জন্য যোগ করে */
        fun onChatScreen()
        /** mode: translate | summary | reply | lang | setup */
        fun onScreen(mode: String, lang: String)
        fun onScreenInsert(text: String)
    }

    class ChatMsg(val fromUser: Boolean, val text: String, val error: Boolean = false)

    private enum class Page { LETTERS, SYMBOLS, VOWELS, EMOJI, CLIP, AI, SCREEN }
    private class LetterKey(val k: Layouts.K, val main: TextView, val hint: TextView?)

    var layoutId = "en"
    var theme: Theme = Themes.all[0]
    var translateTo = "English"
    var screenLang = "Bengali"
    var heightScale = 1f
    var showSuggestions = true
    var showNumbers = true
    var fb: Feedback? = null

    var busy = false
        set(v) {
            field = v
            status.text = if (v) "•••" else ""
        }

    var listening = false
        set(v) {
            if (field != v) {
                field = v
                if (built) refresh()
            }
        }

    private val handler = Handler(Looper.getMainLooper())
    private val rows = LinearLayout(context)
    private var chips: List<TextView> = emptyList()
    private var status = TextView(context)

    private var page = Page.LETTERS
    private var chatOn = false
    private var shift = 0 // 0 বন্ধ, 1 একবার, 2 ক্যাপস
    private var lastShiftTap = 0L
    private var emojiCat = 1
    private var built = false
    private var lastChips: List<String> = emptyList()
    private var lastHighlight = -1

    private val letterKeys = ArrayList<LetterKey>()
    private var shiftView: FrameLayout? = null
    private var shiftLabel: TextView? = null

    private var clips: List<Clip> = emptyList()

    private var chatMsgs: List<ChatMsg> = emptyList()
    private var chatInput = ""
    private var chatBusy = false
    private var chatList: LinearLayout? = null
    private var chatScroll: ScrollView? = null
    private var chatInputView: TextView? = null

    private var screenResults: List<String> = emptyList()
    private var screenBusy = false
    private var screenNeedSetup = false

    init {
        orientation = LinearLayout.VERTICAL
        rows.orientation = LinearLayout.VERTICAL
        isMotionEventSplittingEnabled = true
        rows.isMotionEventSplittingEnabled = true
        refresh()
        built = true
    }

    // ---------- বাইরের API ----------

    fun applyTheme(t: Theme) {
        theme = t
        refresh()
    }

    fun setClips(list: List<Clip>) {
        clips = list
        if (page == Page.CLIP) render()
    }

    fun setChips(list: List<String>, highlight: Int) {
        lastChips = list
        lastHighlight = highlight
        chips.forEachIndexed { i, tv ->
            val t = list.getOrElse(i) { "" }
            tv.text = t
            val hint = t == HINT
            tv.setTextColor(if (i == highlight || hint) theme.accent else theme.text)
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, if (hint) 13f else 17f)
            tv.setTypeface(null, if (i == highlight) Typeface.BOLD else Typeface.NORMAL)
        }
    }

    fun setChat(msgs: List<ChatMsg>, input: String, busyNow: Boolean) {
        val changed = msgs.size != chatMsgs.size || busyNow != chatBusy ||
            (msgs.isNotEmpty() && chatMsgs.isNotEmpty() && msgs.last() !== chatMsgs.last())
        chatMsgs = msgs.toList()
        chatInput = input
        chatBusy = busyNow
        if (!chatOn) return
        showChatInput()
        if (changed) fillChat()
    }

    fun setScreen(results: List<String>, busyNow: Boolean, needSetup: Boolean) {
        screenResults = results
        screenBusy = busyNow
        screenNeedSetup = needSetup
        if (page == Page.SCREEN) render()
    }

    /** পুরো UI নতুন করে আঁকে (থিম/ভাষা/প্যানেল বদলালে) */
    fun refresh() {
        removeAllViews()
        setBackgroundColor(theme.bg)
        setPadding(dp(4), dp(2), dp(4), dp(6))
        addView(buildToolbar(), lp(MATCH, dp(36)))
        if (showSuggestions) addView(buildStrip(), lp(MATCH, dp(42))) else chips = emptyList()
        addView(rows, lp(MATCH, WRAP))
        render()
        setChips(lastChips, lastHighlight)
    }

    // ---------- টুলবার ও সাজেশন স্ট্রিপ ----------

    private fun togglePage(p: Page) {
        page = if (page == p) Page.LETTERS else p
        if (page == Page.SCREEN && chatOn) {
            chatOn = false
            l.onChatMode(false)
        }
        refresh()
    }

    private fun toggleChat() {
        chatOn = !chatOn
        if (chatOn && page == Page.SCREEN) page = Page.LETTERS
        l.onChatMode(chatOn)
        refresh()
    }

    private fun buildToolbar(): LinearLayout {
        val bar = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        fun tool(label: String, on: Boolean, color: Int = theme.text, onTap: () -> Unit) {
            val tv = TextView(context).apply {
                text = label
                gravity = Gravity.CENTER
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
                setTextColor(if (on) theme.onAccent else color)
                background = round(if (on) theme.accent else 0x00000000, 10f)
                setOnClickListener {
                    fb?.key()
                    onTap()
                }
            }
            bar.addView(tv, lp(0, dp(32), 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
        }
        tool("😊", page == Page.EMOJI) { togglePage(Page.EMOJI) }
        tool("📋", page == Page.CLIP) { togglePage(Page.CLIP) }
        tool("✦", page == Page.AI, theme.accent) { togglePage(Page.AI) }
        tool("💬", chatOn) { toggleChat() }
        tool("🌐", page == Page.SCREEN) { togglePage(Page.SCREEN) }
        tool(if (listening) "⏹" else "🎤", listening) { l.onVoice() }
        tool("🎨", false) { l.onThemeNext() }
        tool("⚙", false, theme.sub) { l.onOpenSettings() }
        return bar
    }

    private fun buildStrip(): LinearLayout {
        val strip = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val list = List(3) { TextView(context) }
        list.forEachIndexed { i, tv ->
            tv.gravity = Gravity.CENTER
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            tv.setTextColor(theme.text)
            tv.maxLines = 1
            tv.ellipsize = TextUtils.TruncateAt.END
            tv.setPadding(dp(6), 0, dp(6), 0)
            tv.background = round(0x00000000, 10f)
            tv.setOnClickListener {
                val t = tv.text.toString()
                if (t.isNotEmpty()) {
                    fb?.key()
                    l.onChip(t)
                }
            }
            strip.addView(tv, lp(0, dp(40), 1f))
            if (i < list.size - 1) {
                val d = View(context)
                d.setBackgroundColor(theme.sub)
                d.alpha = 0.35f
                strip.addView(d, lp(dp(1), dp(18)))
            }
        }
        chips = list
        status = TextView(context).apply {
            setTextColor(theme.accent)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            gravity = Gravity.CENTER
        }
        strip.addView(status, lp(dp(28), dp(40)))
        return strip
    }

    // ---------- কী-সারি ও প্যানেল ----------

    private fun kh(base: Int): Int = (dp(base) * heightScale).toInt()

    /** চার সারি কী-র মোট উচ্চতা (প্যানেলের মাপ) */
    private fun panelH(): Int {
        val digit = if (showNumbers) kh(40) + dp(4) else 0
        return digit + 3 * (kh(46) + dp(4))
    }

    private fun render() {
        rows.removeAllViews()
        letterKeys.clear()
        shiftView = null
        shiftLabel = null
        chatList = null
        chatScroll = null
        chatInputView = null
        if (chatOn && page != Page.SCREEN) rows.addView(chatPanel())
        when (page) {
            Page.LETTERS -> letterRows()
            Page.SYMBOLS -> {
                digitRow()?.let { rows.addView(it) }
                pagedRows(Layouts.symbols)
            }
            Page.VOWELS -> {
                digitRow()?.let { rows.addView(it) }
                pagedRows(Layouts.vowels)
            }
            Page.EMOJI -> rows.addView(emojiPanel())
            Page.CLIP -> rows.addView(clipPanel())
            Page.AI -> rows.addView(aiPanel())
            Page.SCREEN -> rows.addView(screenPanel())
        }
        rows.addView(bottomRow())
    }

    private fun letterRows() {
        val bn = layoutId != "en"
        val phonetic = layoutId == "avro"
        val letters: List<List<Layouts.K>> = when (layoutId) {
            "jatiya" -> Layouts.jatiya
            "probhat" -> Layouts.probhat
            else -> Layouts.english
        }
        val hints = bn && !phonetic
        digitRow()?.let { rows.addView(it) }
        rows.addView(row().also { r -> letters[0].forEach { r.addView(letterKey(it, hints)) } })
        rows.addView(row().also { r ->
            r.addView(spacer(0.5f))
            letters[1].forEach { r.addView(letterKey(it, hints)) }
            r.addView(spacer(0.5f))
        })
        rows.addView(row().also { r ->
            r.addView(shiftKey())
            letters[2].forEach { r.addView(letterKey(it, hints)) }
            r.addView(backspaceKey())
        })
    }

    private fun digitRow(): LinearLayout? {
        if (!showNumbers) return null
        val bn = layoutId != "en"
        return row().also { r ->
            val digits = if (bn) Layouts.BN_DIGITS else Layouts.EN_DIGITS
            digits.forEachIndexed { i, d ->
                val latin = Layouts.EN_DIGITS[i].toString()
                r.addView(
                    key(
                        d.toString(), 1f, theme.key, size = 17f, h = 40,
                        hint = if (bn) latin else null,
                        onLong = if (bn) ({ l.onChar(latin) }) else null
                    ) { l.onChar(d.toString()) }
                )
            }
        }
    }

    private fun bottomRow(): LinearLayout = row().also { r ->
        val bn = layoutId != "en"
        val panel = page == Page.EMOJI || page == Page.CLIP || page == Page.AI || page == Page.SCREEN
        if (panel) {
            r.addView(key("ABC", 1.5f, theme.special, size = 14f) {
                page = Page.LETTERS
                refresh()
            })
            r.addView(spaceKey(5f))
            r.addView(backspaceKey())
            r.addView(key("↵", 1.5f, theme.accent, fg = theme.onAccent, size = 22f, kind = 3) { l.onEnter() })
            return@also
        }
        val toggleLabel = when (page) {
            Page.SYMBOLS -> if (bn) "অআ" else "ABC"
            Page.VOWELS -> "ABC"
            else -> "?123"
        }
        r.addView(key(toggleLabel, 1.2f, theme.special, size = 14f) {
            page = when (page) {
                Page.LETTERS -> Page.SYMBOLS
                Page.SYMBOLS -> if (bn) Page.VOWELS else Page.LETTERS
                else -> Page.LETTERS
            }
            render()
        })
        r.addView(key(Layouts.label(layoutId), 1.3f, theme.special, size = 13f) { l.onSwitchLayout(1) })
        val nonPhonetic = layoutId == "jatiya" || layoutId == "probhat"
        if (nonPhonetic) {
            r.addView(key("অ", 1f, theme.special, size = 20f) { l.onChar("অ") })
        } else {
            r.addView(key(",", 1f, theme.special, size = 20f) { l.onChar(",") })
        }
        r.addView(spaceKey(3.4f))
        r.addView(
            key(
                if (bn) "।" else ".", 1f, theme.special, size = 20f,
                hint = if (bn) "." else null,
                onLong = if (bn) ({ l.onChar(".") }) else null
            ) { l.onChar(if (bn) "।" else ".") }
        )
        r.addView(key("↵", 1.3f, theme.accent, fg = theme.onAccent, size = 22f, kind = 3) { l.onEnter() })
    }

    private fun pagedRows(data: List<List<Pair<String, String>>>) {
        rows.addView(row().also { r ->
            data[0].forEach { (label, text) -> r.addView(key(Layouts.shown(label), 1f, theme.key) { l.onChar(text) }) }
        })
        rows.addView(row().also { r ->
            r.addView(spacer(0.5f))
            data[1].forEach { (label, text) -> r.addView(key(Layouts.shown(label), 1f, theme.key) { l.onChar(text) }) }
            r.addView(spacer(0.5f))
        })
        rows.addView(row().also { r ->
            r.addView(spacer(0.5f))
            data[2].forEach { (label, text) -> r.addView(key(Layouts.shown(label), 1f, theme.key) { l.onChar(text) }) }
            r.addView(spacer(0.5f))
            r.addView(backspaceKey())
        })
    }

    private fun letterKey(k: Layouts.K, hints: Boolean): FrameLayout {
        val canHint = hints && k.s != k.n
        val f = key(
            Layouts.shown(if (shift > 0) k.s else k.n), 1f, theme.key,
            hint = if (canHint) Layouts.shown(k.s) else null,
            onLong = if (canHint) ({ l.onChar(k.s) }) else null
        ) {
            l.onChar(if (shift > 0) k.s else k.n)
            if (shift == 1) {
                shift = 0
                applyShift()
            }
        }
        val hintView = if (canHint) f.getChildAt(1) as TextView else null
        hintView?.visibility = if (shift > 0) View.INVISIBLE else View.VISIBLE
        letterKeys.add(LetterKey(k, f.getChildAt(0) as TextView, hintView))
        return f
    }

    /** শিফট বদলালে পুরো UI নয়, শুধু কী-র লেখা বদলায় */
    private fun applyShift() {
        letterKeys.forEach { lk ->
            lk.main.text = Layouts.shown(if (shift > 0) lk.k.s else lk.k.n)
            lk.hint?.visibility = if (shift > 0) View.INVISIBLE else View.VISIBLE
        }
        shiftView?.background = keyBg(if (shift > 0) theme.accent else theme.special)
        shiftLabel?.apply {
            text = if (shift == 2) "⇪" else "⇧"
            setTextColor(if (shift > 0) theme.onAccent else theme.text)
        }
    }

    private fun shiftKey(): FrameLayout {
        val f = key(
            if (shift == 2) "⇪" else "⇧", 1.5f,
            if (shift > 0) theme.accent else theme.special,
            fg = if (shift > 0) theme.onAccent else theme.text, size = 20f
        ) {
            val now = SystemClock.uptimeMillis()
            shift = when {
                now - lastShiftTap < 350 -> 2
                shift == 0 -> 1
                else -> 0
            }
            lastShiftTap = now
            applyShift()
        }
        shiftView = f
        shiftLabel = f.getChildAt(0) as TextView
        return f
    }

    private fun backspaceKey(): FrameLayout =
        key("⌫", 1.5f, theme.special, size = 20f, kind = 2, repeat = true) { l.onBackspace() }

    /** স্পেসবার: চাপলে স্পেস, ডানে/বামে সোয়াইপ করলে ভাষা বদল */
    @SuppressLint("ClickableViewAccessibility")
    private fun spaceKey(weight: Float): FrameLayout {
        val label = "◂  ${Layouts.title(layoutId)}  ▸"
        val f = key(label, weight, theme.key, fg = theme.sub, size = 13f, kind = 1) { }
        var startX = 0f
        var swiped = false
        f.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = e.x
                    swiped = false
                    v.isPressed = true
                    fb?.key(1)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.x - startX
                    if (abs(dx) > dp(40)) {
                        swiped = true
                        startX = e.x
                        l.onSwitchLayout(if (dx > 0) 1 else -1)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    v.isPressed = false
                    if (!swiped && inside(v, e)) l.onSpace()
                }
                MotionEvent.ACTION_CANCEL -> v.isPressed = false
            }
            true
        }
        return f
    }

    // ---------- ইমোজি প্যানেল ----------

    private fun emojiPanel(): View {
        val box = panelBox(panelH())
        val tabs = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        Emojis.cats.forEachIndexed { i, c ->
            val sel = i == emojiCat
            tabs.addView(
                TextView(context).apply {
                    text = c.icon
                    gravity = Gravity.CENTER
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
                    background = round(if (sel) theme.accent else 0x00000000, 10f)
                    setOnClickListener {
                        fb?.key()
                        emojiCat = i
                        render()
                    }
                },
                lp(0, dp(34), 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) }
            )
        }
        box.addView(tabs, lp(MATCH, dp(38)))

        val items = if (emojiCat == 0) l.recentEmojis() else Emojis.cats[emojiCat].items
        val col = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        if (items.isEmpty()) {
            col.addView(note("এখনও কোনো সাম্প্রতিক ইমোজি নেই"))
        } else {
            items.chunked(8).forEach { chunk ->
                val r = row()
                chunk.forEach { e ->
                    r.addView(
                        TextView(context).apply {
                            text = e
                            gravity = Gravity.CENTER
                            setTextSize(TypedValue.COMPLEX_UNIT_SP, 24f)
                            background = round(0x00000000, 8f)
                            setOnClickListener {
                                fb?.key()
                                l.onEmoji(e)
                            }
                        },
                        lp(0, dp(44), 1f)
                    )
                }
                repeat(8 - chunk.size) { r.addView(spacer(1f)) }
                col.addView(r)
            }
        }
        val scroll = ScrollView(context)
        scroll.addView(col)
        box.addView(scroll, lp(MATCH, 0, 1f))
        return box
    }

    // ---------- ক্লিপবোর্ড প্যানেল ----------

    private fun clipPanel(): View {
        val box = panelBox(panelH())
        val top = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        top.addView(
            pill("＋ সিলেক্ট করা লেখা সেভ", theme.key, theme.text, 13f) { l.onClipSaveSelection() },
            lp(0, dp(34), 1f).apply { setMargins(dp(3), dp(2), dp(3), dp(2)) }
        )
        top.addView(
            pill("🗑 পুরোনো মুছুন", theme.key, theme.text, 13f) { l.onClipClear() },
            lp(0, dp(34), 1f).apply { setMargins(dp(3), dp(2), dp(3), dp(2)) }
        )
        box.addView(top, lp(MATCH, dp(38)))

        val col = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        if (clips.isEmpty()) {
            col.addView(note("কপি করা লেখা এখানে জমা হবে।\n📌 চাপলে লেখাটি সেভ থাকবে, নিজে মুছবে না।"))
        } else {
            clips.forEach { col.addView(clipRow(it)) }
        }
        val scroll = ScrollView(context)
        scroll.addView(col)
        box.addView(scroll, lp(MATCH, 0, 1f))
        return box
    }

    private fun clipRow(c: Clip): View {
        val r = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = round(theme.key, 10f)
            layoutParams = lp(MATCH, WRAP).apply { setMargins(dp(3), dp(3), dp(3), 0) }
            minimumHeight = dp(44)
        }
        r.addView(
            TextView(context).apply {
                text = c.text.replace("\n", " ")
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
                setTextColor(theme.text)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                setPadding(dp(10), dp(6), dp(6), dp(6))
                setOnClickListener {
                    fb?.key()
                    l.onClipPaste(c.text)
                }
            },
            lp(0, WRAP, 1f)
        )
        r.addView(
            TextView(context).apply {
                text = "📌"
                gravity = Gravity.CENTER
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                alpha = if (c.pinned) 1f else 0.3f
                setOnClickListener {
                    fb?.key()
                    l.onClipPin(c.text)
                }
            },
            lp(dp(40), dp(40))
        )
        r.addView(
            TextView(context).apply {
                text = "✕"
                gravity = Gravity.CENTER
                setTextColor(theme.sub)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                setOnClickListener {
                    fb?.key()
                    l.onClipDelete(c.text)
                }
            },
            lp(dp(40), dp(40))
        )
        return r
    }

    // ---------- AI প্যানেল ----------

    private fun aiPanel(): View {
        val box = panelBox(panelH())
        box.addView(
            note("ফিল্ডে লেখা বা প্রম্পট লিখুন (বা সিলেক্ট করুন), তারপর একটি বাটন চাপুন")
                .apply { setPadding(dp(6), dp(2), dp(6), 0) },
            lp(MATCH, WRAP)
        )

        fun addRow(items: List<Triple<String, Boolean, () -> Unit>>) {
            val r = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
            items.forEach { (label, primary, act) ->
                r.addView(
                    pill(
                        label,
                        if (primary) theme.accent else theme.key,
                        if (primary) theme.onAccent else theme.text,
                        14f, onTap = act
                    ),
                    lp(0, dp(38), 1f).apply { setMargins(dp(3), dp(4), dp(3), 0) }
                )
            }
            box.addView(r, lp(MATCH, WRAP))
        }
        addRow(
            listOf(
                Triple("✍ লিখে দাও", true, { l.onAi("write", "") }),
                Triple("✦ ঠিক করো", false, { l.onAi("fix", "") }),
                Triple("↩ আগেরটা", false, { l.onAi("undo", "") })
            )
        )
        addRow(
            listOf(
                Triple("✂ ছোট", false, { l.onAi("shorter", "") }),
                Triple("➕ বড়", false, { l.onAi("longer", "") }),
                Triple("👔 ফরমাল", false, { l.onAi("formal", "") }),
                Triple("😊 ঘরোয়া", false, { l.onAi("friendly", "") })
            )
        )

        box.addView(
            note("🌐 অনুবাদ — ভাষা বাছুন:").apply { setPadding(dp(6), dp(8), dp(6), 0) },
            lp(MATCH, WRAP)
        )
        box.addView(langScroll(translateTo) { name ->
            translateTo = name
            l.onAi("translate", name)
            render()
        }, lp(MATCH, WRAP))
        return box
    }

    private fun langScroll(selected: String, onPick: (String) -> Unit): View {
        val langRow = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        LANGS.forEach { (label, name) ->
            val sel = name == selected
            langRow.addView(
                pill(
                    label,
                    if (sel) theme.accent else theme.key,
                    if (sel) theme.onAccent else theme.text, 14f
                ) { onPick(name) },
                lp(WRAP, dp(36)).apply { setMargins(dp(3), dp(4), dp(3), 0) }
            )
        }
        return HorizontalScrollView(context).apply {
            isHorizontalScrollBarEnabled = false
            addView(langRow)
        }
    }

    // ---------- স্ক্রিন অনুবাদ প্যানেল ----------

    private fun screenPanel(): View {
        val box = panelBox(panelH() + dp(46))
        val modes = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(
            Triple("🌐 অনুবাদ", "translate", true),
            Triple("📝 সারাংশ", "summary", false),
            Triple("💡 রিপ্লাই", "reply", false)
        ).forEach { (label, mode, primary) ->
            modes.addView(
                pill(
                    label,
                    if (primary) theme.accent else theme.key,
                    if (primary) theme.onAccent else theme.text, 14f
                ) { l.onScreen(mode, screenLang) },
                lp(0, dp(38), 1f).apply { setMargins(dp(3), dp(2), dp(3), 0) }
            )
        }
        box.addView(modes, lp(MATCH, dp(40)))
        box.addView(note("ভাষা (অনুবাদ/সারাংশ যে ভাষায় চান):").apply { setPadding(dp(6), dp(4), dp(6), 0) }, lp(MATCH, WRAP))
        box.addView(langScroll(screenLang) { name ->
            screenLang = name
            l.onScreen("lang", name)
            render()
        }, lp(MATCH, dp(42)))

        val col = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        when {
            screenNeedSetup -> col.addView(
                bubble("⚠ স্ক্রিন পড়ার জন্য Accessibility সার্ভিস চালু করতে হবে। এখানে চাপুন।", false) {
                    l.onScreen("setup", "")
                }
            )
            screenBusy -> col.addView(bubble("•••", false, null))
            screenResults.isEmpty() -> col.addView(
                note("চ্যাট বা যেকোনো স্ক্রিন খুলে কীবোর্ড তুলুন, তারপর বাটন চাপুন। ফলাফলে চাপলে লেখা ফিল্ডে বসবে।")
            )
            else -> screenResults.forEach { r -> col.addView(bubble(r, false) { l.onScreenInsert(r) }) }
        }
        val scroll = ScrollView(context)
        scroll.addView(col)
        box.addView(scroll, lp(MATCH, 0, 1f))
        return box
    }

    // ---------- Gemini চ্যাট প্যানেল ----------

    private fun chatPanel(): View {
        val box = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            background = round(theme.panel, 14f, theme.panel)
            layoutParams = lp(MATCH, WRAP).apply { setMargins(dp(2), dp(4), dp(2), dp(2)) }
            setPadding(dp(4), dp(2), dp(4), dp(4))
        }
        val head = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(
            TextView(context).apply {
                text = "💬 Gemini চ্যাট"
                setTextColor(theme.sub)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                setTypeface(null, Typeface.BOLD)
                setPadding(dp(6), 0, 0, 0)
            },
            lp(0, WRAP, 1f)
        )
        head.addView(
            pill("🖥 স্ক্রিন যোগ", theme.key, theme.text, 12f, 8) { l.onChatScreen() },
            lp(WRAP, dp(26)).apply { setMargins(dp(2), 0, dp(2), 0) }
        )
        head.addView(
            pill("🗑", theme.key, theme.text, 13f, 0) { l.onChatClear() },
            lp(dp(40), dp(26)).apply { setMargins(dp(2), 0, dp(2), 0) }
        )
        head.addView(
            pill("✕", theme.key, theme.text, 13f, 0) { toggleChat() },
            lp(dp(40), dp(26)).apply { setMargins(dp(2), 0, dp(2), 0) }
        )
        box.addView(head, lp(MATCH, dp(30)))

        val scroll = ScrollView(context)
        val col = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(col)
        chatScroll = scroll
        chatList = col
        box.addView(scroll, lp(MATCH, dp(104)))

        val inputRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val input = TextView(context).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.START
            setPadding(dp(10), dp(4), dp(10), dp(4))
            background = round(theme.key, 12f, theme.key)
            gravity = Gravity.CENTER_VERTICAL
        }
        chatInputView = input
        inputRow.addView(input, lp(0, dp(40), 1f))
        inputRow.addView(
            pill("➤", theme.accent, theme.onAccent, 18f, 0) { l.onChatSend() },
            lp(dp(48), dp(40)).apply { setMargins(dp(4), 0, 0, 0) }
        )
        box.addView(inputRow, lp(MATCH, dp(44)))
        fillChat()
        showChatInput()
        return box
    }

    private fun showChatInput() {
        val v = chatInputView ?: return
        if (chatInput.isEmpty()) {
            v.text = "Gemini-কে লিখুন…"
            v.setTextColor(theme.sub)
        } else {
            v.text = chatInput + "▍"
            v.setTextColor(theme.text)
        }
    }

    private fun fillChat() {
        val col = chatList ?: return
        col.removeAllViews()
        if (chatMsgs.isEmpty() && !chatBusy) {
            col.addView(note("যেকোনো প্রশ্ন করুন। উত্তরে চাপলে সেটি ফিল্ডে বসবে।"))
        }
        chatMsgs.forEach { m ->
            if (m.fromUser) col.addView(bubble(m.text, true, null))
            else col.addView(bubble(m.text, false) { if (!m.error) l.onChatInsert(m.text) })
        }
        if (chatBusy) col.addView(bubble("•••", false, null))
        chatScroll?.post { chatScroll?.fullScroll(View.FOCUS_DOWN) }
    }

    private fun bubble(text: String, mine: Boolean, onTap: (() -> Unit)?): View {
        val tv = TextView(context).apply {
            this.text = text
            setTextColor(if (mine) theme.onAccent else theme.text)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setPadding(dp(10), dp(6), dp(10), dp(6))
            maxWidth = (resources.displayMetrics.widthPixels * 0.82f).toInt()
            background = round(if (mine) theme.accent else theme.key, 12f, if (mine) theme.accent else theme.key)
            if (onTap != null) setOnClickListener {
                fb?.key()
                onTap()
            }
        }
        tv.layoutParams = lp(WRAP, WRAP).apply {
            gravity = if (mine) Gravity.END else Gravity.START
            setMargins(dp(6), dp(3), dp(6), dp(3))
        }
        return tv
    }

    // ---------- সহায়ক ----------

    private fun panelBox(h: Int): LinearLayout = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        layoutParams = lp(MATCH, h)
    }

    private fun note(s: String) = TextView(context).apply {
        text = s
        setTextColor(theme.sub)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        setPadding(dp(8), dp(12), dp(8), dp(4))
    }

    private fun pill(
        label: String, fill: Int, fg: Int, size: Float = 14f, padH: Int = 12, onTap: () -> Unit
    ) = TextView(context).apply {
        text = label
        setTextColor(fg)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
        gravity = Gravity.CENTER
        maxLines = 1
        setPadding(dp(padH), 0, dp(padH), 0)
        background = round(fill, 18f)
        setOnClickListener {
            fb?.key()
            onTap()
        }
    }

    private fun row(): LinearLayout = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL
        isMotionEventSplittingEnabled = true
        layoutParams = lp(MATCH, WRAP)
    }

    private fun spacer(w: Float) = View(context).apply {
        layoutParams = lp(0, 1, w)
    }

    private fun inside(v: View, e: MotionEvent) = e.x >= 0 && e.y >= 0 && e.x <= v.width && e.y <= v.height

    /**
     * একটি কী। আঙুল নামালে ভাইব্রেশন/শব্দ ও চাপা-রঙ, তোলার সময় লেখা (দ্রুত ও নিখুঁত)।
     * repeat = চেপে ধরলে বারবার (ব্যাকস্পেস), onLong = লং-প্রেসে বিকল্প অক্ষর।
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun key(
        label: String, weight: Float, fill: Int,
        fg: Int = theme.text, size: Float = 20f, h: Int = 46,
        hint: String? = null, kind: Int = 0, repeat: Boolean = false,
        onLong: (() -> Unit)? = null,
        onTap: () -> Unit
    ): FrameLayout {
        val f = FrameLayout(context)
        f.background = keyBg(fill)
        f.layoutParams = lp(0, kh(h), weight).apply { setMargins(dp(3), dp(4), dp(3), 0) }
        val main = TextView(context).apply {
            text = label
            gravity = Gravity.CENTER
            setTextColor(fg)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
            maxLines = 1
            includeFontPadding = false
        }
        f.addView(main, FrameLayout.LayoutParams(MATCH, MATCH))
        if (hint != null) {
            val ht = TextView(context).apply {
                text = hint
                setTextColor(theme.sub)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
                includeFontPadding = false
            }
            f.addView(
                ht,
                FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.END).apply {
                    setMargins(0, dp(2), dp(5), 0)
                }
            )
        }
        var down = false
        var longFired = false
        val longRun = Runnable {
            if (down && onLong != null) {
                longFired = true
                fb?.buzz()
                onLong()
            }
        }
        val repRun = object : Runnable {
            override fun run() {
                if (down) {
                    onTap()
                    handler.postDelayed(this, 45)
                }
            }
        }
        f.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    down = true
                    longFired = false
                    v.isPressed = true
                    fb?.key(kind)
                    if (repeat) {
                        onTap()
                        handler.postDelayed(repRun, 380)
                    } else if (onLong != null) {
                        handler.postDelayed(longRun, 350)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    v.isPressed = false
                    handler.removeCallbacks(longRun)
                    handler.removeCallbacks(repRun)
                    if (down && !repeat && !longFired && inside(v, e)) onTap()
                    down = false
                }
                MotionEvent.ACTION_CANCEL -> {
                    v.isPressed = false
                    handler.removeCallbacks(longRun)
                    handler.removeCallbacks(repRun)
                    down = false
                }
            }
            true
        }
        return f
    }

    /** নিচে হালকা ছায়াসহ কী-এর ব্যাকগ্রাউন্ড; চাপলে accent-মেশানো রং */
    private fun keyBg(fill: Int): Drawable {
        val r = dp(11).toFloat()
        fun layer(face: Int): Drawable {
            val shadow = GradientDrawable().apply {
                setColor(Themes.mix(face, 0xFF000000.toInt(), 0.22f))
                cornerRadius = r
            }
            val top = GradientDrawable().apply {
                setColor(face)
                cornerRadius = r
            }
            return LayerDrawable(arrayOf<Drawable>(shadow, top)).apply { setLayerInset(1, 0, 0, 0, dp(2)) }
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), layer(Themes.mix(fill, theme.accent, 0.5f)))
            addState(intArrayOf(), layer(fill))
        }
    }

    private fun round(fill: Int, radiusDp: Float, pressed: Int? = null): Drawable {
        val r = dp(radiusDp.toInt()).toFloat()
        val press = pressed ?: if ((fill ushr 24) == 0) Themes.mix(theme.bg, theme.accent, 0.25f)
        else Themes.mix(fill, theme.accent, 0.35f)
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), GradientDrawable().apply {
                setColor(press)
                cornerRadius = r
            })
            addState(intArrayOf(), GradientDrawable().apply {
                setColor(fill)
                cornerRadius = r
            })
        }
    }

    private fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    companion object {
        const val HINT = "⚙ Gemini API কী দিন"
        private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

        /** (দেখানো নাম, Gemini-কে দেওয়া ভাষার নাম) */
        val LANGS = listOf(
            "English" to "English", "বাংলা" to "Bengali", "हिन्दी" to "Hindi",
            "العربية" to "Arabic", "اردو" to "Urdu", "Español" to "Spanish",
            "Français" to "French", "Deutsch" to "German", "日本語" to "Japanese",
            "한국어" to "Korean", "中文" to "Chinese", "Türkçe" to "Turkish",
            "Русский" to "Russian", "Indonesia" to "Indonesian", "Melayu" to "Malay"
        )
    }
}
