package com.example.geminikeyboard

import android.content.Context
import android.content.res.Configuration

/** সব বাটন একই রঙের; শুধু এন্টার/সেন্ড/সিলেক্টেড বাটনে accent রং। */
class Theme(
    val id: String,
    val name: String,
    val bg: Int,
    val key: Int,
    val special: Int,
    val panel: Int,
    val accent: Int,
    val onAccent: Int,
    val text: Int,
    val sub: Int
)

object Themes {
    fun mix(a: Int, b: Int, t: Float): Int {
        fun ch(s: Int) = ((((a shr s) and 0xFF) * (1 - t)) + (((b shr s) and 0xFF) * t)).toInt()
        return (0xFF shl 24) or (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
    }

    private fun rgb(v: Long) = (0xFF000000 or v).toInt()

    private fun t(
        id: String, name: String, bg: Long, key: Long, accent: Long,
        onAccent: Long, text: Long, sub: Long
    ): Theme {
        val b = rgb(bg)
        val k = rgb(key)
        return Theme(
            id, name, b, k, mix(k, b, 0.5f), mix(b, k, 0.5f),
            rgb(accent), rgb(onAccent), rgb(text), rgb(sub)
        )
    }

    val all: List<Theme> = listOf(
        t("light", "লাইট", 0xE9ECF4, 0xFFFFFF, 0x4F5EE8, 0xFFFFFF, 0x1B1E26, 0x6B7385),
        t("dark", "ডার্ক", 0x12141A, 0x262B36, 0x8B9BFF, 0x0E1230, 0xECEFF4, 0x8A93A6),
        t("amoled", "অ্যামোলেড", 0x000000, 0x1A1C21, 0x4DD0A8, 0x00201A, 0xFFFFFF, 0x8A8F99),
        t("ocean", "সমুদ্র", 0x0A2239, 0x15395C, 0x38BDF8, 0x06263A, 0xE6F4FF, 0x8FB3D1),
        t("forest", "বন", 0x10251A, 0x1D3B2B, 0x4ADE80, 0x052E16, 0xE8F5EC, 0x8DB79C),
        t("violet", "বেগুনি", 0x1B1030, 0x2F1E52, 0xC084FC, 0x2A0A4A, 0xF3E8FF, 0xA78BCB),
        t("sunset", "সূর্যাস্ত", 0x2A1B3D, 0x40295C, 0xFB923C, 0x3A1A00, 0xFBEFFF, 0xB79BD1),
        t("rose", "গোলাপ", 0xFBE3EC, 0xFFFFFF, 0xE91E63, 0xFFFFFF, 0x3B1020, 0x9C5A70),
        t("mint", "পুদিনা", 0xD9F2E8, 0xFFFFFF, 0x0F9D76, 0xFFFFFF, 0x0E2F26, 0x5C8A7B),
        t("sand", "বালি", 0xEDE3D5, 0xFFFBF4, 0x8D5A2B, 0xFFFFFF, 0x2E2118, 0x7C6A58)
    )

    fun byId(id: String): Theme = all.firstOrNull { it.id == id } ?: all[0]

    /** "auto" হলে সিস্টেমের ডার্ক/লাইট অনুসরণ করে */
    fun resolve(context: Context, id: String): Theme {
        if (id != "auto") return byId(id)
        val night = (context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        return byId(if (night) "dark" else "light")
    }
}
