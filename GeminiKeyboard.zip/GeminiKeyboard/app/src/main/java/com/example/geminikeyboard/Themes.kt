package com.example.geminikeyboard

import android.content.Context
import android.content.res.Configuration

class Theme(
    val id: String,
    val name: String,
    val bg: Int,
    val key: Int,
    val special: Int,
    val accent: Int,
    val onAccent: Int,
    val text: Int,
    val sub: Int,
    val ripple: Int
)

object Themes {
    private fun t(
        id: String, name: String, bg: Long, key: Long, special: Long, accent: Long,
        onAccent: Long, text: Long, sub: Long, ripple: Long
    ) = Theme(
        id, name, (0xFF000000 or bg).toInt(), (0xFF000000 or key).toInt(),
        (0xFF000000 or special).toInt(), (0xFF000000 or accent).toInt(),
        (0xFF000000 or onAccent).toInt(), (0xFF000000 or text).toInt(),
        (0xFF000000 or sub).toInt(), ripple.toInt()
    )

    val all: List<Theme> = listOf(
        t("light", "লাইট", 0xE8EBF1, 0xFFFFFF, 0xCDD3DF, 0x4F5EE8, 0xFFFFFF, 0x1B1E26, 0x6B7385, 0x22000000),
        t("dark", "ডার্ক", 0x14161B, 0x262A33, 0x1D2027, 0x7C8CFF, 0x10142B, 0xECEFF4, 0x8A93A6, 0x33FFFFFF),
        t("amoled", "অ্যামোলেড", 0x000000, 0x16181D, 0x0C0D10, 0x4DD0A8, 0x00201A, 0xFFFFFF, 0x8A8F99, 0x33FFFFFF),
        t("ocean", "সমুদ্র", 0x0B2540, 0x13395F, 0x0E2D4D, 0x38BDF8, 0x06263A, 0xE6F4FF, 0x8FB3D1, 0x33FFFFFF),
        t("forest", "বন", 0x12261C, 0x1C3A2A, 0x163021, 0x4ADE80, 0x052E16, 0xE8F5EC, 0x8DB79C, 0x33FFFFFF),
        t("rose", "গোলাপ", 0xFCE4EC, 0xFFFFFF, 0xF8BBD0, 0xE91E63, 0xFFFFFF, 0x3B1020, 0x9C5A70, 0x22000000),
        t("sunset", "সূর্যাস্ত", 0x2A1B3D, 0x3D2A57, 0x33224A, 0xFB923C, 0x3A1A00, 0xFBEFFF, 0xB79BD1, 0x33FFFFFF),
        t("sand", "বালি", 0xEFE6DA, 0xFFFBF5, 0xD9C9B3, 0x8D5A2B, 0xFFFFFF, 0x2E2118, 0x7C6A58, 0x22000000)
    )

    fun byId(id: String): Theme = all.firstOrNull { it.id == id } ?: all[0]

    /** "auto" হলে সিস্টেমের ডার্ক/লাইট অনুসরণ করে */
    fun resolve(context: Context, id: String): Theme {
        if (id != "auto") return byId(id)
        val night = (context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        return byId(if (night) "dark" else "light")
    }
}
