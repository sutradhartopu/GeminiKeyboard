package com.example.geminikeyboard

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Clip(val text: String, val pinned: Boolean, val time: Long)

/** কপি করা লেখার ইতিহাস। 📌 দেওয়া লেখা (সেভ করা) কখনো নিজে থেকে মোছে না। */
class ClipStore(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("clips", Context.MODE_PRIVATE)

    private fun load(): MutableList<Clip> {
        val out = mutableListOf<Clip>()
        try {
            val arr = JSONArray(sp.getString("items", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Clip(o.getString("t"), o.optBoolean("p"), o.optLong("ts")))
            }
        } catch (e: Exception) {
            // নষ্ট ডেটা উপেক্ষা
        }
        return out
    }

    private fun save(list: List<Clip>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("t", it.text).put("p", it.pinned).put("ts", it.time)) }
        sp.edit().putString("items", arr.toString()).apply()
    }

    /** পিন করা আগে, তারপর নতুন থেকে পুরোনো */
    fun all(): List<Clip> {
        val l = load()
        return l.filter { it.pinned } + l.filter { !it.pinned }
    }

    fun add(text: String, pin: Boolean = false) {
        val l = load()
        val old = l.firstOrNull { it.text == text }
        l.removeAll { it.text == text }
        l.add(0, Clip(text, pin || (old?.pinned ?: false), System.currentTimeMillis()))
        var count = 0
        save(l.filter { if (it.pinned) true else { count++; count <= MAX_UNPINNED } })
    }

    fun togglePin(text: String) {
        save(load().map { if (it.text == text) it.copy(pinned = !it.pinned) else it })
    }

    fun remove(text: String) {
        save(load().filter { it.text != text })
    }

    fun clearUnpinned() {
        save(load().filter { it.pinned })
    }

    companion object {
        const val MAX_UNPINNED = 40
    }
}
