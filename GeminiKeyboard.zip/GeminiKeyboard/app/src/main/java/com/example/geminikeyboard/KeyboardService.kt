package com.example.geminikeyboard

import android.Manifest
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.inputmethodservice.InputMethodService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class KeyboardService : InputMethodService(), KeyboardView.Listener {

    private lateinit var prefs: Prefs
    private lateinit var gemini: GeminiClient
    private lateinit var clipStore: ClipStore
    private lateinit var cm: ClipboardManager
    private lateinit var fb: Feedback
    private var kbView: KeyboardView? = null

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val handler = Handler(Looper.getMainLooper())
    private var suggestJob: Job? = null

    /** বর্তমান শব্দের কাঁচা ইনপুট (অভ্র মোডে ল্যাটিন, অন্য মোডে সরাসরি অক্ষর) */
    private val raw = StringBuilder()
    private var curLayout = "en"
    private var composeAllowed = true
    private var aiAllowed = true

    private var correctionFor: String? = null
    private var correction: String? = null

    // AI "আগেরটা" ফেরানোর জন্য
    private var undoOriginal: String? = null
    private var undoInserted: String? = null

    // ভয়েস
    private var recognizer: SpeechRecognizer? = null
    private var voiceOn = false
    private var voicePartial = ""

    // কীবোর্ডের ভেতরের Gemini চ্যাট
    private var chatOn = false
    private val chatText = StringBuilder()
    private val chatMsgs = mutableListOf<KeyboardView.ChatMsg>()
    private val chatHistory = mutableListOf<Pair<Boolean, String>>()
    private var chatBusy = false
    private var chatJob: Job? = null
    private var attachedScreen: String? = null

    // স্ক্রিন অনুবাদ
    private var screenJob: Job? = null

    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener { captureClip() }

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key != null && key !in Prefs.NO_REFRESH) handler.post { applyPrefsToView() }
    }

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        gemini = GeminiClient(prefs)
        clipStore = ClipStore(this)
        fb = Feedback(this)
        curLayout = prefs.curLayout
        cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.addPrimaryClipChangedListener(clipListener)
        prefs.listen(prefListener)
        Dictionary.load(this)
    }

    override fun onCreateInputView(): View {
        val v = KeyboardView(this, this)
        kbView = v
        applyPrefsToView()
        return v
    }

    /** ল্যান্ডস্কেপেও বড় ফুলস্ক্রিন এডিটর নয়, সাধারণ কীবোর্ড */
    override fun onEvaluateFullscreenMode(): Boolean = false

    private fun enabledLayouts(): List<String> {
        val l = prefs.enabledLayouts.split(",").map { it.trim() }.filter { it in Layouts.ids }
        return if (l.isEmpty()) listOf("en") else l
    }

    private fun bnMode() = curLayout != "en"
    private fun phonetic() = curLayout == "avro"

    private fun applyPrefsToView() {
        val v = kbView ?: return
        val list = enabledLayouts()
        if (curLayout !in list) curLayout = list[0]
        fb.vibrate = prefs.vibrate
        fb.vibrateMs = prefs.vibrateMs
        fb.soundMode = prefs.soundMode
        fb.volume = prefs.soundVol / 100f
        v.fb = fb
        v.theme = Themes.resolve(this, prefs.theme)
        v.layoutId = curLayout
        v.heightScale = prefs.heightPct / 100f
        v.showSuggestions = prefs.showSuggestions
        v.showNumbers = prefs.showNumbers
        v.translateTo = prefs.translateTo
        v.screenLang = prefs.screenLang
        v.setClips(clipStore.all())
        v.refresh()
        updateChat()
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        raw.clear()
        correction = null
        val cls = (info?.inputType ?: 0) and InputType.TYPE_MASK_CLASS
        val variation = (info?.inputType ?: 0) and InputType.TYPE_MASK_VARIATION
        composeAllowed = cls == InputType.TYPE_CLASS_TEXT
        val sensitive = variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
            variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
            variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
            variation == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS ||
            variation == InputType.TYPE_TEXT_VARIATION_URI
        val incognito = ((info?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING) != 0
        // পাসওয়ার্ড, ইমেইল, URL ও ইনকগনিটো ফিল্ডের লেখা কখনো Gemini-তে যায় না
        aiAllowed = composeAllowed && !sensitive && !incognito
        captureClip()
        applyPrefsToView()
        scheduleSuggestions()
    }

    override fun onFinishInput() {
        super.onFinishInput()
        raw.clear()
        suggestJob?.cancel()
        stopVoice()
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int, newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        // ব্যবহারকারী কার্সর সরালে কম্পোজিং শেষ (চ্যাট মোডে কাঁচা ইনপুট হোস্ট ফিল্ডে নেই)
        if (!chatOn && raw.isNotEmpty() && candidatesStart == -1 && candidatesEnd == -1) {
            raw.clear()
            scheduleSuggestions()
        }
    }

    override fun onDestroy() {
        stopVoice()
        cm.removePrimaryClipChangedListener(clipListener)
        prefs.unlisten(prefListener)
        scope.cancel()
        super.onDestroy()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    // ---------- ইনপুট ----------

    private fun isWordChar(c: Char): Boolean {
        if (Character.isLetter(c)) return true
        val t = Character.getType(c)
        return t == Character.NON_SPACING_MARK.toInt() || t == Character.COMBINING_SPACING_MARK.toInt()
    }

    private fun displayed(): String =
        if (phonetic()) AvroEngine.convert(raw.toString()) else raw.toString()

    /** লেখা বসানোর একমাত্র পথ: চ্যাট চালু থাকলে চ্যাটের ইনপুটে, নইলে হোস্ট ফিল্ডে */
    private fun put(text: String) {
        if (chatOn) {
            chatText.append(text)
            updateChat()
        } else {
            currentInputConnection?.commitText(text, 1)
        }
    }

    private fun commitComposing() {
        if (raw.isEmpty()) return
        val t = displayed()
        raw.clear()
        put(t)
    }

    override fun onChar(text: String) {
        if ((chatOn || composeAllowed) && text.all { isWordChar(it) }) {
            raw.append(text)
            if (chatOn) updateChat() else currentInputConnection?.setComposingText(displayed(), 1)
        } else {
            commitComposing()
            put(text)
        }
        scheduleSuggestions()
    }

    override fun onBackspace() {
        if (raw.isNotEmpty()) {
            raw.deleteCharAt(raw.length - 1)
            if (chatOn) {
                updateChat()
            } else {
                val ic = currentInputConnection
                ic?.setComposingText(displayed(), 1)
                if (raw.isEmpty()) ic?.finishComposingText()
            }
        } else if (chatOn) {
            if (chatText.isNotEmpty()) {
                val n = if (chatText.length > 1 && Character.isLowSurrogate(chatText.last())) 2 else 1
                chatText.setLength(chatText.length - n)
            }
            updateChat()
        } else {
            val ic = currentInputConnection ?: return
            val sel = ic.getSelectedText(0)
            if (!sel.isNullOrEmpty()) ic.commitText("", 1)
            else sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        }
        scheduleSuggestions()
    }

    override fun onSpace() {
        if (raw.isNotEmpty()) {
            val shown = displayed()
            val fix = correction
            val word = if (prefs.autoCorrect && (aiAllowed || chatOn) && !fix.isNullOrEmpty() &&
                correctionFor == shown
            ) fix else shown
            raw.clear()
            put("$word ")
        } else {
            put(" ")
        }
        correction = null
        scheduleSuggestions()
    }

    override fun onEnter() {
        if (chatOn) {
            sendChat()
            return
        }
        val ic = currentInputConnection ?: return
        commitComposing()
        val info = currentInputEditorInfo
        val action = (info?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        val noEnterAction = ((info?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noEnterAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action)
        } else {
            ic.commitText("\n", 1)
        }
        scheduleSuggestions()
    }

    override fun onChip(text: String) {
        if (text == KeyboardView.HINT) {
            openSettings()
            return
        }
        raw.clear()
        put("$text ")
        correction = null
        scheduleSuggestions()
    }

    override fun onSwitchLayout(dir: Int) {
        val list = enabledLayouts()
        val i = list.indexOf(curLayout).let { if (it < 0) 0 else it }
        commitComposing()
        curLayout = list[(i + dir + list.size) % list.size]
        prefs.curLayout = curLayout
        correction = null
        applyPrefsToView()
        scheduleSuggestions()
    }

    override fun onOpenSettings() = openSettings()

    private fun openSettings() {
        startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    // ---------- ইমোজি ও থিম ----------

    override fun onEmoji(e: String) {
        commitComposing()
        put(e)
        val list = (listOf(e) + recentEmojis().filter { it != e }).take(32)
        prefs.recentEmoji = list.joinToString(" ")
    }

    override fun recentEmojis(): List<String> =
        prefs.recentEmoji.split(" ").filter { it.isNotEmpty() }

    override fun onThemeNext() {
        val ids = listOf("auto") + Themes.all.map { it.id }
        val next = ids[(ids.indexOf(prefs.theme) + 1) % ids.size]
        prefs.theme = next // প্রেফারেন্স-লিসেনার কীবোর্ড রিফ্রেশ করবে
        toast("থিম: " + if (next == "auto") "অটো" else Themes.byId(next).name)
    }

    // ---------- ক্লিপবোর্ড ----------

    private fun captureClip() {
        try {
            val clip = cm.primaryClip ?: return
            if (clip.itemCount == 0) return
            if (clip.description?.extras?.getBoolean("android.content.extra.IS_SENSITIVE") == true) return
            val text = clip.getItemAt(0).coerceToText(this)?.toString()?.trim().orEmpty()
            if (text.isEmpty() || text.length > 5000) return
            clipStore.add(text)
            kbView?.setClips(clipStore.all())
        } catch (e: Exception) {
            // কিছু ডিভাইসে ক্লিপবোর্ড পড়া নিষিদ্ধ থাকতে পারে
        }
    }

    override fun onClipPaste(text: String) {
        commitComposing()
        put(text)
    }

    override fun onClipPin(text: String) {
        clipStore.togglePin(text)
        kbView?.setClips(clipStore.all())
    }

    override fun onClipDelete(text: String) {
        clipStore.remove(text)
        kbView?.setClips(clipStore.all())
    }

    override fun onClipClear() {
        clipStore.clearUnpinned()
        kbView?.setClips(clipStore.all())
        toast("সেভ না করা লেখা মোছা হয়েছে")
    }

    override fun onClipSaveSelection() {
        val sel = currentInputConnection?.getSelectedText(0)?.toString().orEmpty()
        if (sel.isBlank()) {
            toast("আগে ফিল্ডে লেখা সিলেক্ট করুন")
            return
        }
        clipStore.add(sel.trim(), pin = true)
        kbView?.setClips(clipStore.all())
        toast("সেভ হয়েছে 📌")
    }

    // ---------- ভয়েস টাইপিং ----------

    override fun onVoice() {
        if (voiceOn) {
            stopVoice()
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            startActivity(
                Intent(this, MicPermissionActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            toast("মাইক্রোফোনের অনুমতি দিন, তারপর আবার 🎤 চাপুন")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            toast("এই ফোনে ভয়েস রিকগনিশন সার্ভিস নেই")
            return
        }
        commitComposing()
        voiceOn = true
        kbView?.listening = true
        startListening()
    }

    private fun startListening() {
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onPartialResults(partialResults: Bundle?) {
                val t = partialResults
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t.isNullOrEmpty()) return
                if (chatOn) {
                    voicePartial = t
                    updateChat()
                } else {
                    currentInputConnection?.setComposingText(t, 1)
                }
            }

            override fun onResults(results: Bundle?) {
                val t = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                voicePartial = ""
                if (!t.isNullOrEmpty()) put("$t ")
                else currentInputConnection?.finishComposingText()
                restartVoice()
            }

            override fun onError(error: Int) {
                voicePartial = ""
                currentInputConnection?.finishComposingText()
                when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH,
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT,
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> restartVoice()
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                        toast("মাইক্রোফোনের অনুমতি নেই")
                        stopVoice()
                    }
                    SpeechRecognizer.ERROR_NETWORK,
                    SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> {
                        toast("ভয়েসের জন্য ইন্টারনেট লাগবে")
                        stopVoice()
                    }
                    else -> {
                        toast("ভয়েস ত্রুটি ($error)")
                        stopVoice()
                    }
                }
            }
        })
        recognizer = r
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (bnMode()) "bn-BD" else "en-US")
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        r.startListening(intent)
    }

    private fun restartVoice() {
        if (!voiceOn) return
        handler.postDelayed({ if (voiceOn) startListening() }, 250)
    }

    private fun stopVoice() {
        voiceOn = false
        voicePartial = ""
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        recognizer = null
        kbView?.listening = false
    }

    // ---------- সাজেশন: অভিধান (তাৎক্ষণিক) + Gemini ----------

    /** অভ্র ইঞ্জিনের ড় ঢ় য় (এক কোডপয়েন্ট) → অভিধানের রূপ (নুক্তা আলাদা) */
    private fun normBn(s: String): String = s
        .replace("ড়", "ড়")
        .replace("ঢ়", "ঢ়")
        .replace("য়", "য়")

    private fun dictWords(shown: String): List<String> {
        if (!prefs.dictSuggest || shown.isEmpty()) return emptyList()
        val bn = shown.any { it.code in 0x0980..0x09FF }
        return Dictionary.suggest(if (bn) normBn(shown) else shown, 3)
    }

    private fun contextBefore(shown: String): String {
        if (chatOn) return chatText.toString().takeLast(80)
        var b = currentInputConnection?.getTextBeforeCursor(80, 0)?.toString().orEmpty()
        if (shown.isNotEmpty() && b.endsWith(shown)) b = b.dropLast(shown.length)
        return b
    }

    private fun scheduleSuggestions() {
        suggestJob?.cancel()
        val view = kbView ?: return
        if (!prefs.showSuggestions) return
        val shown = displayed()
        val dict = dictWords(shown)
        val base = if (shown.isNotEmpty()) (listOf(shown) + dict).distinct().take(3) else emptyList()
        val aiOk = (aiAllowed || chatOn) && prefs.aiEnabled

        if (!aiOk) {
            view.busy = false
            view.setChips(base, -1)
            return
        }
        if (prefs.apiKey.isEmpty()) {
            view.busy = false
            view.setChips(if (base.isNotEmpty()) base else listOf("", KeyboardView.HINT), -1)
            return
        }

        view.setChips(base, -1)
        val rawNow = raw.toString()
        val phon = phonetic()

        suggestJob = scope.launch {
            delay(if (shown.isEmpty()) 350L else 300L)
            val before = contextBefore(shown)
            view.busy = true
            val res = withContext(Dispatchers.IO) { gemini.suggest(before, shown, rawNow, phon) }
            view.busy = false
            if (res == null || displayed() != shown) return@launch

            val fix = res.correction.takeIf { it.isNotEmpty() && it != shown }
            correction = fix
            correctionFor = shown
            val merged = mutableListOf<String>()
            if (fix != null) merged.add(fix)
            if (shown.isNotEmpty()) merged.add(shown)
            val n = maxOf(res.words.size, dict.size)
            for (i in 0 until n) {
                res.words.getOrNull(i)?.let { merged.add(it) }
                dict.getOrNull(i)?.let { merged.add(it) }
            }
            view.setChips(merged.distinct().take(3), if (fix != null) 0 else -1)
        }
    }

    // ---------- Gemini: লেখা, অনুবাদ, ঠিক করা (হোস্ট ফিল্ডে) ----------

    private fun instructionFor(action: String, arg: String): String? = when (action) {
        "write" -> "The text below is a request or prompt from the user. Write the requested content " +
            "directly. Use the same language as the prompt unless the prompt asks for another language. " +
            "Keep it natural and ready to send."
        "fix" -> "Fix spelling, grammar and punctuation of the text. Keep the same language(s) " +
            "(Bengali and/or English), meaning, tone, emojis and line breaks. Do not translate and do not add anything."
        "shorter" -> "Rewrite the text shorter and clearer. Keep the same language, meaning and key details."
        "longer" -> "Rewrite the text with more detail and better flow. Keep the same language and meaning."
        "formal" -> "Rewrite the text in a polite, formal tone. Keep the same language and meaning."
        "friendly" -> "Rewrite the text in a warm, casual, friendly tone. Keep the same language and meaning."
        "translate" -> "Translate the text into $arg. Keep meaning, tone, emojis, numbers and line breaks."
        else -> null
    }

    override fun onAi(action: String, arg: String) {
        val ic = currentInputConnection ?: return

        if (action == "undo") {
            val ins = undoInserted
            val orig = undoOriginal
            if (ins == null || orig == null) {
                toast("ফেরানোর মতো কিছু নেই")
                return
            }
            val before = ic.getTextBeforeCursor(ins.length, 0)?.toString()
            if (before == ins) {
                ic.deleteSurroundingText(ins.length, 0)
                ic.commitText(orig, 1)
                undoInserted = null
                toast("আগের লেখা ফিরেছে")
            } else {
                toast("লেখা বদলে গেছে, ফেরানো যায়নি")
            }
            return
        }

        if (!(aiAllowed && prefs.aiEnabled && prefs.apiKey.isNotEmpty())) {
            toast(
                when {
                    !aiAllowed -> "এই ফিল্ডে AI বন্ধ (নিরাপত্তার জন্য)"
                    prefs.apiKey.isEmpty() -> "আগে অ্যাপে Gemini API কী দিন"
                    else -> "AI সেটিংসে বন্ধ আছে"
                }
            )
            return
        }
        val instruction = instructionFor(action, arg) ?: return
        if (action == "translate") prefs.translateTo = arg

        commitComposing()
        val selected = ic.getSelectedText(0)?.toString().orEmpty()
        val hasSel = selected.isNotEmpty()
        val before = if (hasSel) "" else ic.getTextBeforeCursor(2000, 0)?.toString().orEmpty()
        val after = if (hasSel) "" else ic.getTextAfterCursor(2000, 0)?.toString().orEmpty()
        val source = if (hasSel) selected else before + after
        if (source.isBlank()) {
            toast("আগে ফিল্ডে কিছু লিখুন বা সিলেক্ট করুন")
            return
        }

        val view = kbView
        view?.busy = true
        scope.launch {
            val out = withContext(Dispatchers.IO) { gemini.transform(instruction, source) }
            view?.busy = false
            val icNow = currentInputConnection ?: return@launch
            when {
                out == null -> toast("ব্যর্থ: ${gemini.lastError ?: ""}")
                out == source -> toast("কোনো পরিবর্তন হয়নি")
                else -> {
                    if (!hasSel) {
                        val still = icNow.getTextBeforeCursor(before.length, 0)?.toString()
                        if (still != before) {
                            toast("অপেক্ষার সময় লেখা বদলে গেছে, আবার চেষ্টা করুন")
                            return@launch
                        }
                        icNow.deleteSurroundingText(before.length, after.length)
                    }
                    icNow.commitText(out, 1)
                    undoOriginal = source
                    undoInserted = out
                    toast("হয়েছে ✓")
                }
            }
            scheduleSuggestions()
        }
    }

    // ---------- কীবোর্ডের ভেতরের Gemini চ্যাট ----------

    private fun updateChat() {
        if (!chatOn) return
        kbView?.setChat(chatMsgs, chatText.toString() + displayed() + voicePartial, chatBusy)
    }

    override fun onChatMode(on: Boolean) {
        if (on == chatOn) return
        // আগের মোডের অসমাপ্ত লেখা সংশ্লিষ্ট জায়গায় ঢুকিয়ে দিই
        commitComposing()
        currentInputConnection?.finishComposingText()
        chatOn = on
        raw.clear()
        correction = null
        if (on) updateChat()
        scheduleSuggestions()
    }

    override fun onChatSend() {
        commitComposing()
        sendChat()
    }

    private fun sendChat() {
        commitComposing()
        val q = chatText.toString().trim()
        if (q.isEmpty() || chatBusy) return
        if (!prefs.aiEnabled || prefs.apiKey.isEmpty()) {
            toast("আগে অ্যাপে Gemini API কী দিন")
            return
        }
        val screen = attachedScreen
        attachedScreen = null
        val full = if (screen != null)
            "Here is the text currently visible on my phone screen:\n$screen\n\nMy request: $q"
        else q
        chatMsgs.add(KeyboardView.ChatMsg(true, q))
        chatHistory.add(true to full)
        while (chatHistory.size > 40) chatHistory.removeAt(0)
        chatText.clear()
        chatBusy = true
        updateChat()
        chatJob = scope.launch {
            val turns = chatHistory.takeLast(20).dropWhile { !it.first }
            val reply = withContext(Dispatchers.IO) { gemini.chat(turns) }
            chatBusy = false
            if (reply == null) {
                chatMsgs.add(KeyboardView.ChatMsg(false, "⚠ ${gemini.lastError ?: "ব্যর্থ"}", true))
            } else {
                chatMsgs.add(KeyboardView.ChatMsg(false, reply.trim()))
                chatHistory.add(false to reply.trim())
            }
            updateChat()
        }
    }

    override fun onChatClear() {
        chatJob?.cancel()
        chatBusy = false
        chatMsgs.clear()
        chatHistory.clear()
        chatText.clear()
        raw.clear()
        attachedScreen = null
        updateChat()
    }

    override fun onChatInsert(text: String) {
        currentInputConnection?.commitText(text, 1)
        toast("ফিল্ডে বসানো হয়েছে")
    }

    override fun onChatScreen() {
        val reader = ScreenReaderService.instance
        if (reader == null) {
            chatMsgs.add(
                KeyboardView.ChatMsg(false, "⚠ স্ক্রিন পড়তে আগে সেটিংসে 'স্ক্রিন অনুবাদ' সার্ভিস চালু করুন।", true)
            )
            updateChat()
            return
        }
        scope.launch {
            val t = withContext(Dispatchers.IO) { reader.readScreen() }
            if (t == null) {
                toast("স্ক্রিনে পড়ার মতো লেখা পাওয়া যায়নি")
            } else {
                attachedScreen = t
                chatMsgs.add(KeyboardView.ChatMsg(false, "🖥 স্ক্রিনের লেখা যোগ হয়েছে। এখন প্রশ্ন লিখে পাঠান।", true))
                updateChat()
            }
        }
    }

    // ---------- স্ক্রিন অনুবাদ / সারাংশ / রিপ্লাই ----------

    override fun onScreen(mode: String, lang: String) {
        when (mode) {
            "lang" -> {
                prefs.screenLang = lang
                return
            }
            "setup" -> {
                startActivity(
                    Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                toast("'জেমিনি কীবোর্ড স্ক্রিন রিডার' চালু করুন")
                return
            }
        }
        if (!prefs.aiEnabled || prefs.apiKey.isEmpty()) {
            toast("আগে অ্যাপে Gemini API কী দিন এবং AI চালু রাখুন")
            return
        }
        val reader = ScreenReaderService.instance
        if (reader == null) {
            kbView?.setScreen(emptyList(), false, true)
            return
        }
        val view = kbView ?: return
        val intro = "The text below was read from a phone screen (probably a chat or social media app). " +
            "Each line is one UI text fragment. Ignore UI chrome such as buttons, menus, times, battery " +
            "and icon labels; focus on the real content.\n"
        val instruction = when (mode) {
            "summary" -> intro + "Summarize the conversation or screen in $lang using 3 to 6 short lines."
            "reply" -> intro + "You are helping the phone's user answer. Suggest 3 short, natural reply " +
                "messages to the latest message, in the language the chat uses (use $lang if unclear). " +
                "Separate the 3 replies with a line containing only ---."
            else -> intro + "Translate the actual content into $lang. Keep each speaker's name and the " +
                "message order, one message per line like 'Name: message'."
        }
        screenJob?.cancel()
        view.setScreen(emptyList(), true, false)
        screenJob = scope.launch {
            val text = withContext(Dispatchers.IO) { reader.readScreen() }
            if (text == null) {
                view.setScreen(listOf("স্ক্রিনে পড়ার মতো লেখা পাওয়া যায়নি।"), false, false)
                return@launch
            }
            val out = withContext(Dispatchers.IO) { gemini.transform(instruction, text) }
            if (out == null) {
                view.setScreen(listOf("⚠ ${gemini.lastError ?: "ব্যর্থ"}"), false, false)
                return@launch
            }
            val results = if (mode == "reply")
                out.split(Regex("\\n\\s*-{3,}\\s*\\n")).map { it.trim() }.filter { it.isNotEmpty() }.take(4)
            else listOf(out.trim())
            view.setScreen(results.ifEmpty { listOf(out.trim()) }, false, false)
        }
    }

    override fun onScreenInsert(text: String) {
        currentInputConnection?.commitText(text, 1)
        toast("ফিল্ডে বসানো হয়েছে")
    }
}
