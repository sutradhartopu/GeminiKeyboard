package com.example.geminikeyboard

import android.content.Intent
import android.inputmethodservice.InputMethodService
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class KeyboardService : InputMethodService(), KeyboardView.Listener {

    private lateinit var prefs: Prefs
    private lateinit var gemini: GeminiClient
    private var kbView: KeyboardView? = null

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var suggestJob: Job? = null

    /** বর্তমান শব্দের কাঁচা ইনপুট (অভ্র মোডে ল্যাটিন, অন্য মোডে সরাসরি অক্ষর) */
    private val raw = StringBuilder()
    private var bnMode = false
    private var composeAllowed = true
    private var aiAllowed = true

    private var correctionFor: String? = null
    private var correction: String? = null

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        gemini = GeminiClient(prefs)
    }

    override fun onCreateInputView(): View {
        val v = KeyboardView(this, this)
        kbView = v
        applyPrefsToView()
        return v
    }

    private fun applyPrefsToView() {
        kbView?.apply {
            bnLayout = prefs.bnLayout
            haptics = prefs.haptics
            mode = if (bnMode) KeyboardView.Mode.BN else KeyboardView.Mode.EN
            render()
        }
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        raw.clear()
        correction = null
        val cls = (info?.inputType ?: 0) and InputType.TYPE_MASK_CLASS
        val variation = (info?.inputType ?: 0) and InputType.TYPE_MASK_VARIATION
        composeAllowed = cls == InputType.TYPE_CLASS_TEXT
        val sensitive = variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
            variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
            variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
            variation == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS ||
            variation == InputType.TYPE_TEXT_VARIATION_URI
        val incognito = ((info?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING) != 0
        // পাসওয়ার্ড, ইমেইল, URL ও ইনকগনিটো ফিল্ডের লেখা কখনো Gemini-তে যায় না
        aiAllowed = composeAllowed && !sensitive && !incognito
        applyPrefsToView()
        scheduleSuggestions()
    }

    override fun onFinishInput() {
        super.onFinishInput()
        raw.clear()
        suggestJob?.cancel()
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int, newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        // ব্যবহারকারী কার্সর সরালে কম্পোজিং শেষ
        if (raw.isNotEmpty() && candidatesStart == -1 && candidatesEnd == -1) {
            raw.clear()
            scheduleSuggestions()
        }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    // ---------- ইনপুট ----------

    private fun isWordChar(c: Char): Boolean {
        if (Character.isLetter(c)) return true
        val t = Character.getType(c)
        return t == Character.NON_SPACING_MARK.toInt() || t == Character.COMBINING_SPACING_MARK.toInt()
    }

    private fun phonetic() = bnMode && prefs.bnLayout == "avro"

    private fun displayed(): String =
        if (phonetic()) AvroEngine.convert(raw.toString()) else raw.toString()

    private fun commitComposing() {
        if (raw.isEmpty()) return
        currentInputConnection?.commitText(displayed(), 1)
        raw.clear()
    }

    override fun onChar(text: String) {
        val ic = currentInputConnection ?: return
        if (composeAllowed && text.all { isWordChar(it) }) {
            raw.append(text)
            ic.setComposingText(displayed(), 1)
        } else {
            commitComposing()
            ic.commitText(text, 1)
        }
        scheduleSuggestions()
    }

    override fun onBackspace() {
        val ic = currentInputConnection ?: return
        if (raw.isNotEmpty()) {
            raw.deleteCharAt(raw.length - 1)
            ic.setComposingText(displayed(), 1)
            if (raw.isEmpty()) ic.finishComposingText()
        } else {
            val sel = ic.getSelectedText(0)
            if (!sel.isNullOrEmpty()) ic.commitText("", 1)
            else sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        }
        scheduleSuggestions()
    }

    override fun onSpace() {
        val ic = currentInputConnection ?: return
        if (raw.isNotEmpty()) {
            val shown = displayed()
            val fix = correction
            val word = if (prefs.autoCorrect && aiAllowed && !fix.isNullOrEmpty() &&
                correctionFor == shown
            ) fix else shown
            ic.commitText("$word ", 1)
            raw.clear()
        } else {
            ic.commitText(" ", 1)
        }
        correction = null
        scheduleSuggestions()
    }

    override fun onEnter() {
        val ic = currentInputConnection ?: return
        commitComposing()
        val info = currentInputEditorInfo
        val action = (info?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        val noEnterAction = ((info?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noEnterAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action)
        } else {
            ic.commitText("\n", 1)
        }
        scheduleSuggestions()
    }

    override fun onChip(text: String) {
        if (text == KeyboardView.HINT) {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        }
        val ic = currentInputConnection ?: return
        ic.commitText("$text ", 1)
        raw.clear()
        correction = null
        scheduleSuggestions()
    }

    override fun onLangToggle() {
        commitComposing()
        bnMode = !bnMode
        correction = null
        applyPrefsToView()
        scheduleSuggestions()
    }

    // ---------- Gemini ----------

    private fun aiReady() = aiAllowed && prefs.aiEnabled && prefs.apiKey.isNotEmpty()

    private fun scheduleSuggestions() {
        suggestJob?.cancel()
        val view = kbView ?: return
        val shown = displayed()

        if (!aiAllowed || !prefs.aiEnabled) {
            view.busy = false
            view.setChips(if (shown.isNotEmpty()) listOf(shown) else emptyList(), -1)
            return
        }
        if (prefs.apiKey.isEmpty()) {
            view.busy = false
            view.setChips(if (shown.isNotEmpty()) listOf(shown) else listOf("", KeyboardView.HINT), -1)
            return
        }

        view.setChips(if (shown.isNotEmpty()) listOf(shown) else emptyList(), -1)
        val ic = currentInputConnection ?: return
        var before = ic.getTextBeforeCursor(80, 0)?.toString().orEmpty()
        if (shown.isNotEmpty() && before.endsWith(shown)) before = before.dropLast(shown.length)
        val rawNow = raw.toString()
        val phon = phonetic()

        suggestJob = scope.launch {
            delay(if (shown.isEmpty()) 150L else 250L)
            view.busy = true
            val res = withContext(Dispatchers.IO) { gemini.suggest(before, shown, rawNow, phon) }
            view.busy = false
            if (res == null || displayed() != shown) return@launch

            val fix = res.correction.takeIf { it.isNotEmpty() && it != shown }
            correction = fix
            correctionFor = shown
            val list = mutableListOf<String>()
            var highlight = -1
            if (shown.isEmpty()) {
                list.addAll(res.words)
            } else {
                if (fix != null) {
                    list.add(fix); highlight = 0
                }
                list.add(shown)
                list.addAll(res.words)
            }
            view.setChips(list.distinct().take(3), highlight)
        }
    }

    /** ✦ বাটন: নির্বাচিত লেখা বা কার্সরের আগের অংশ Gemini দিয়ে ঠিক করা */
    override fun onFix() {
        val ic = currentInputConnection ?: return
        if (!aiReady()) {
            val msg = when {
                !aiAllowed -> "এই ফিল্ডে AI বন্ধ (নিরাপত্তার জন্য)"
                prefs.apiKey.isEmpty() -> "আগে অ্যাপে Gemini API কী দিন"
                else -> "AI সাজেশন সেটিংসে বন্ধ আছে"
            }
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
            return
        }
        commitComposing()
        val selected = ic.getSelectedText(0)?.toString().orEmpty()
        val hasSelection = selected.isNotEmpty()
        val original = if (hasSelection) selected
        else ic.getTextBeforeCursor(400, 0)?.toString().orEmpty()
        if (original.isBlank()) return

        val view = kbView
        view?.busy = true
        scope.launch {
            val fixed = withContext(Dispatchers.IO) { gemini.fix(original) }
            view?.busy = false
            val icNow = currentInputConnection ?: return@launch
            when {
                fixed == null -> Toast.makeText(
                    this@KeyboardService, "ঠিক করা যায়নি: ${gemini.lastError ?: ""}", Toast.LENGTH_SHORT
                ).show()
                fixed == original -> Toast.makeText(this@KeyboardService, "ভুল পাওয়া যায়নি ✓", Toast.LENGTH_SHORT).show()
                else -> {
                    if (!hasSelection) icNow.deleteSurroundingText(original.length, 0)
                    icNow.commitText(fixed, 1)
                    Toast.makeText(this@KeyboardService, "ঠিক করা হয়েছে ✓", Toast.LENGTH_SHORT).show()
                }
            }
            scheduleSuggestions()
        }
    }
}
