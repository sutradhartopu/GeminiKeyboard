package com.example.geminikeyboard

import android.Manifest
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.inputmethodservice.InputMethodService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class KeyboardService : InputMethodService(), KeyboardView.Listener {

    private lateinit var prefs: Prefs
    private lateinit var gemini: GeminiClient
    private lateinit var clipStore: ClipStore
    private lateinit var cm: ClipboardManager
    private var kbView: KeyboardView? = null

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val handler = Handler(Looper.getMainLooper())
    private var suggestJob: Job? = null

    /** বর্তমান শব্দের কাঁচা ইনপুট (অভ্র মোডে ল্যাটিন, অন্য মোডে সরাসরি অক্ষর) */
    private val raw = StringBuilder()
    private var bnMode = false
    private var composeAllowed = true
    private var aiAllowed = true

    private var correctionFor: String? = null
    private var correction: String? = null

    // AI "আগেরটা" ফেরানোর জন্য
    private var undoOriginal: String? = null
    private var undoInserted: String? = null

    // ভয়েস
    private var recognizer: SpeechRecognizer? = null
    private var voiceOn = false

    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener { captureClip() }

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        gemini = GeminiClient(prefs)
        clipStore = ClipStore(this)
        cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.addPrimaryClipChangedListener(clipListener)
    }

    override fun onCreateInputView(): View {
        val v = KeyboardView(this, this)
        kbView = v
        applyPrefsToView()
        return v
    }

    private fun applyPrefsToView() {
        val v = kbView ?: return
        v.theme = Themes.resolve(this, prefs.theme)
        v.bnLayout = prefs.bnLayout
        v.haptics = prefs.haptics
        v.translateTo = prefs.translateTo
        v.mode = if (bnMode) KeyboardView.Mode.BN else KeyboardView.Mode.EN
        v.setClips(clipStore.all())
        v.refresh()
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        raw.clear()
        correction = null
        val cls = (info?.inputType ?: 0) and InputType.TYPE_MASK_CLASS
        val variation = (info?.inputType ?: 0) and InputType.TYPE_MASK_VARIATION
        composeAllowed = cls == InputType.TYPE_CLASS_TEXT
        val sensitive = variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
            variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
            variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
            variation == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS ||
            variation == InputType.TYPE_TEXT_VARIATION_URI
        val incognito = ((info?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING) != 0
        // পাসওয়ার্ড, ইমেইল, URL ও ইনকগনিটো ফিল্ডের লেখা কখনো Gemini-তে যায় না
        aiAllowed = composeAllowed && !sensitive && !incognito
        captureClip()
        applyPrefsToView()
        scheduleSuggestions()
    }

    override fun onFinishInput() {
        super.onFinishInput()
        raw.clear()
        suggestJob?.cancel()
        stopVoice()
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int, newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        // ব্যবহারকারী কার্সর সরালে কম্পোজিং শেষ
        if (raw.isNotEmpty() && candidatesStart == -1 && candidatesEnd == -1) {
            raw.clear()
            scheduleSuggestions()
        }
    }

    override fun onDestroy() {
        stopVoice()
        cm.removePrimaryClipChangedListener(clipListener)
        scope.cancel()
        super.onDestroy()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    // ---------- ইনপুট ----------

    private fun isWordChar(c: Char): Boolean {
        if (Character.isLetter(c)) return true
        val t = Character.getType(c)
        return t == Character.NON_SPACING_MARK.toInt() || t == Character.COMBINING_SPACING_MARK.toInt()
    }

    private fun phonetic() = bnMode && prefs.bnLayout == "avro"

    private fun displayed(): String =
        if (phonetic()) AvroEngine.convert(raw.toString()) else raw.toString()

    private fun commitComposing() {
        if (raw.isEmpty()) return
        currentInputConnection?.commitText(displayed(), 1)
        raw.clear()
    }

    override fun onChar(text: String) {
        val ic = currentInputConnection ?: return
        if (composeAllowed && text.all { isWordChar(it) }) {
            raw.append(text)
            ic.setComposingText(displayed(), 1)
        } else {
            commitComposing()
            ic.commitText(text, 1)
        }
        scheduleSuggestions()
    }

    override fun onBackspace() {
        val ic = currentInputConnection ?: return
        if (raw.isNotEmpty()) {
            raw.deleteCharAt(raw.length - 1)
            ic.setComposingText(displayed(), 1)
            if (raw.isEmpty()) ic.finishComposingText()
        } else {
            val sel = ic.getSelectedText(0)
            if (!sel.isNullOrEmpty()) ic.commitText("", 1)
            else sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        }
        scheduleSuggestions()
    }

    override fun onSpace() {
        val ic = currentInputConnection ?: return
        if (raw.isNotEmpty()) {
            val shown = displayed()
            val fix = correction
            val word = if (prefs.autoCorrect && aiAllowed && !fix.isNullOrEmpty() &&
                correctionFor == shown
            ) fix else shown
            ic.commitText("$word ", 1)
            raw.clear()
        } else {
            ic.commitText(" ", 1)
        }
        correction = null
        scheduleSuggestions()
    }

    override fun onEnter() {
        val ic = currentInputConnection ?: return
        commitComposing()
        val info = currentInputEditorInfo
        val action = (info?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        val noEnterAction = ((info?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noEnterAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action)
        } else {
            ic.commitText("\n", 1)
        }
        scheduleSuggestions()
    }

    override fun onChip(text: String) {
        if (text == KeyboardView.HINT) {
            openSettings()
            return
        }
        val ic = currentInputConnection ?: return
        ic.commitText("$text ", 1)
        raw.clear()
        correction = null
        scheduleSuggestions()
    }

    override fun onLangToggle() {
        commitComposing()
        bnMode = !bnMode
        correction = null
        applyPrefsToView()
        scheduleSuggestions()
    }

    override fun onOpenSettings() = openSettings()

    private fun openSettings() {
        startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    // ---------- ইমোজি ----------

    override fun onEmoji(e: String) {
        commitComposing()
        currentInputConnection?.commitText(e, 1)
        val list = (listOf(e) + recentEmojis().filter { it != e }).take(32)
        prefs.recentEmoji = list.joinToString(" ")
    }

    override fun recentEmojis(): List<String> =
        prefs.recentEmoji.split(" ").filter { it.isNotEmpty() }

    // ---------- থিম ----------

    override fun onThemeNext() {
        val ids = listOf("auto") + Themes.all.map { it.id }
        val next = ids[(ids.indexOf(prefs.theme) + 1) % ids.size]
        prefs.theme = next
        kbView?.applyTheme(Themes.resolve(this, next))
        toast("থিম: " + if (next == "auto") "অটো" else Themes.byId(next).name)
    }

    // ---------- ক্লিপবোর্ড ----------

    private fun captureClip() {
        try {
            val clip = cm.primaryClip ?: return
            if (clip.itemCount == 0) return
            if (clip.description?.extras?.getBoolean("android.content.extra.IS_SENSITIVE") == true) return
            val text = clip.getItemAt(0).coerceToText(this)?.toString()?.trim().orEmpty()
            if (text.isEmpty() || text.length > 5000) return
            clipStore.add(text)
            kbView?.setClips(clipStore.all())
        } catch (e: Exception) {
            // কিছু ডিভাইসে ক্লিপবোর্ড পড়া নিষিদ্ধ থাকতে পারে
        }
    }

    override fun onClipPaste(text: String) {
        commitComposing()
        currentInputConnection?.commitText(text, 1)
    }

    override fun onClipPin(text: String) {
        clipStore.togglePin(text)
        kbView?.setClips(clipStore.all())
    }

    override fun onClipDelete(text: String) {
        clipStore.remove(text)
        kbView?.setClips(clipStore.all())
    }

    override fun onClipClear() {
        clipStore.clearUnpinned()
        kbView?.setClips(clipStore.all())
        toast("সেভ না করা লেখা মোছা হয়েছে")
    }

    override fun onClipSaveSelection() {
        val sel = currentInputConnection?.getSelectedText(0)?.toString().orEmpty()
        if (sel.isBlank()) {
            toast("আগে ফিল্ডে লেখা সিলেক্ট করুন")
            return
        }
        clipStore.add(sel.trim(), pin = true)
        kbView?.setClips(clipStore.all())
        toast("সেভ হয়েছে 📌")
    }

    // ---------- ভয়েস টাইপিং ----------

    override fun onVoice() {
        if (voiceOn) {
            stopVoice()
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            startActivity(
                Intent(this, MicPermissionActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            toast("মাইক্রোফোনের অনুমতি দিন, তারপর আবার 🎤 চাপুন")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            toast("এই ফোনে ভয়েস রিকগনিশন সার্ভিস নেই")
            return
        }
        commitComposing()
        voiceOn = true
        kbView?.listening = true
        startListening()
    }

    private fun startListening() {
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onPartialResults(partialResults: Bundle?) {
                val t = partialResults
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrEmpty()) currentInputConnection?.setComposingText(t, 1)
            }

            override fun onResults(results: Bundle?) {
                val t = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrEmpty()) currentInputConnection?.commitText("$t ", 1)
                else currentInputConnection?.finishComposingText()
                restartVoice()
            }

            override fun onError(error: Int) {
                currentInputConnection?.finishComposingText()
                when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH,
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT,
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> restartVoice()
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                        toast("মাইক্রোফোনের অনুমতি নেই")
                        stopVoice()
                    }
                    SpeechRecognizer.ERROR_NETWORK,
                    SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> {
                        toast("ভয়েসের জন্য ইন্টারনেট লাগবে")
                        stopVoice()
                    }
                    else -> {
                        toast("ভয়েস ত্রুটি ($error)")
                        stopVoice()
                    }
                }
            }
        })
        recognizer = r
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (bnMode) "bn-BD" else "en-US")
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        r.startListening(intent)
    }

    private fun restartVoice() {
        if (!voiceOn) return
        handler.postDelayed({ if (voiceOn) startListening() }, 250)
    }

    private fun stopVoice() {
        voiceOn = false
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        recognizer = null
        kbView?.listening = false
    }

    // ---------- Gemini: সাজেশন ----------

    private fun aiReady() = aiAllowed && prefs.aiEnabled && prefs.apiKey.isNotEmpty()

    private fun scheduleSuggestions() {
        suggestJob?.cancel()
        val view = kbView ?: return
        val shown = displayed()

        if (!aiAllowed || !prefs.aiEnabled) {
            view.busy = false
            view.setChips(if (shown.isNotEmpty()) listOf(shown) else emptyList(), -1)
            return
        }
        if (prefs.apiKey.isEmpty()) {
            view.busy = false
            view.setChips(if (shown.isNotEmpty()) listOf(shown) else listOf("", KeyboardView.HINT), -1)
            return
        }

        view.setChips(if (shown.isNotEmpty()) listOf(shown) else emptyList(), -1)
        val ic = currentInputConnection ?: return
        var before = ic.getTextBeforeCursor(80, 0)?.toString().orEmpty()
        if (shown.isNotEmpty() && before.endsWith(shown)) before = before.dropLast(shown.length)
        val rawNow = raw.toString()
        val phon = phonetic()

        suggestJob = scope.launch {
            delay(if (shown.isEmpty()) 150L else 250L)
            view.busy = true
            val res = withContext(Dispatchers.IO) { gemini.suggest(before, shown, rawNow, phon) }
            view.busy = false
            if (res == null || displayed() != shown) return@launch

            val fix = res.correction.takeIf { it.isNotEmpty() && it != shown }
            correction = fix
            correctionFor = shown
            val list = mutableListOf<String>()
            var highlight = -1
            if (shown.isEmpty()) {
                list.addAll(res.words)
            } else {
                if (fix != null) {
                    list.add(fix)
                    highlight = 0
                }
                list.add(shown)
                list.addAll(res.words)
            }
            view.setChips(list.distinct().take(3), highlight)
        }
    }

    // ---------- Gemini: লেখা, অনুবাদ, ঠিক করা ----------

    private fun instructionFor(action: String, arg: String): String? = when (action) {
        "write" -> "The text below is a request or prompt from the user. Write the requested content " +
            "directly. Use the same language as the prompt unless the prompt asks for another language. " +
            "Keep it natural and ready to send."
        "fix" -> "Fix spelling, grammar and punctuation of the text. Keep the same language(s) " +
            "(Bengali and/or English), meaning, tone, emojis and line breaks. Do not translate and do not add anything."
        "shorter" -> "Rewrite the text shorter and clearer. Keep the same language, meaning and key details."
        "longer" -> "Rewrite the text with more detail and better flow. Keep the same language and meaning."
        "formal" -> "Rewrite the text in a polite, formal tone. Keep the same language and meaning."
        "friendly" -> "Rewrite the text in a warm, casual, friendly tone. Keep the same language and meaning."
        "translate" -> "Translate the text into $arg. Keep meaning, tone, emojis, numbers and line breaks."
        else -> null
    }

    override fun onAi(action: String, arg: String) {
        val ic = currentInputConnection ?: return

        if (action == "undo") {
            val ins = undoInserted
            val orig = undoOriginal
            if (ins == null || orig == null) {
                toast("ফেরানোর মতো কিছু নেই")
                return
            }
            val before = ic.getTextBeforeCursor(ins.length, 0)?.toString()
            if (before == ins) {
                ic.deleteSurroundingText(ins.length, 0)
                ic.commitText(orig, 1)
                undoInserted = null
                toast("আগের লেখা ফিরেছে")
            } else {
                toast("লেখা বদলে গেছে, ফেরানো যায়নি")
            }
            return
        }

        if (!aiReady()) {
            toast(
                when {
                    !aiAllowed -> "এই ফিল্ডে AI বন্ধ (নিরাপত্তার জন্য)"
                    prefs.apiKey.isEmpty() -> "আগে অ্যাপে Gemini API কী দিন"
                    else -> "AI সেটিংসে বন্ধ আছে"
                }
            )
            return
        }
        val instruction = instructionFor(action, arg) ?: return
        if (action == "translate") prefs.translateTo = arg

        commitComposing()
        val selected = ic.getSelectedText(0)?.toString().orEmpty()
        val hasSel = selected.isNotEmpty()
        val before = if (hasSel) "" else ic.getTextBeforeCursor(2000, 0)?.toString().orEmpty()
        val after = if (hasSel) "" else ic.getTextAfterCursor(2000, 0)?.toString().orEmpty()
        val source = if (hasSel) selected else before + after
        if (source.isBlank()) {
            toast("আগে ফিল্ডে কিছু লিখুন বা সিলেক্ট করুন")
            return
        }

        val view = kbView
        view?.busy = true
        scope.launch {
            val out = withContext(Dispatchers.IO) { gemini.transform(instruction, source) }
            view?.busy = false
            val icNow = currentInputConnection ?: return@launch
            when {
                out == null -> toast("ব্যর্থ: ${gemini.lastError ?: ""}")
                out == source -> toast("কোনো পরিবর্তন হয়নি")
                else -> {
                    if (!hasSel) {
                        val still = icNow.getTextBeforeCursor(before.length, 0)?.toString()
                        if (still != before) {
                            toast("অপেক্ষার সময় লেখা বদলে গেছে, আবার চেষ্টা করুন")
                            return@launch
                        }
                        icNow.deleteSurroundingText(before.length, after.length)
                    }
                    icNow.commitText(out, 1)
                    undoOriginal = source
                    undoInserted = out
                    toast("হয়েছে ✓")
                }
            }
            scheduleSuggestions()
        }
    }
}
