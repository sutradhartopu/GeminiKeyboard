package com.example.geminikeyboard

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

/** সেটিংস ও সেটআপ স্ক্রিন। পরিবর্তন সাথে সাথে কীবোর্ডে কার্যকর হয়। */
class MainActivity : Activity() {

    private val accent = 0xFF4F5EE8.toInt()
    private val bg = 0xFFF3F4F9.toInt()
    private val grey = 0xFF6B7385.toInt()

    private lateinit var prefs: Prefs
    private lateinit var themeRow: LinearLayout
    private lateinit var micStatus: TextView
    private lateinit var a11yStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        window.statusBarColor = bg
        setContentView(build())
    }

    override fun onResume() {
        super.onResume()
        if (::micStatus.isInitialized) updateStatuses()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        updateStatuses()
    }

    private fun micGranted() =
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun updateStatuses() {
        val ok = 0xFF1B8A4B.toInt()
        val bad = 0xFFC62828.toInt()
        micStatus.text = if (micGranted()) "✓ মাইক্রোফোনের অনুমতি দেওয়া আছে" else "✗ অনুমতি দেওয়া হয়নি"
        micStatus.setTextColor(if (micGranted()) ok else bad)
        val on = ScreenReaderService.instance != null
        a11yStatus.text = if (on) "✓ স্ক্রিন রিডার চালু আছে" else "✗ চালু নেই"
        a11yStatus.setTextColor(if (on) ok else bad)
    }

    private fun build(): ScrollView {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(32))
        }

        root.addView(text("জেমিনি কীবোর্ড", 26f, bold = true))
        root.addView(
            text("বাংলা ও English • Gemini AI চ্যাট • স্ক্রিন অনুবাদ • ভয়েস • ক্লিপবোর্ড • ইমোজি • থিম", 14f, grey)
                .apply { setPadding(0, dp(4), 0, dp(16)) }
        )

        // ধাপ ১-২
        root.addView(card("ধাপ ১ ও ২ — কীবোর্ড চালু করুন").also { c ->
            c.addView(button("১. কীবোর্ড সক্রিয় করুন") {
                startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
            })
            c.addView(button("২. এই কীবোর্ড বেছে নিন") {
                (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
            })
        })

        // ধাপ ৩: API কী
        val keyField = field("Gemini API কী", prefs.apiKey, password = true)
        val modelField = field("মডেল", prefs.model)
        val result = text("", 13f)
        root.addView(card("ধাপ ৩ — Gemini API").also { c ->
            c.addView(text("aistudio.google.com থেকে বিনামূল্যে কী নিতে পারেন।", 13f, grey))
            c.addView(keyField)
            c.addView(modelField)
            c.addView(button("সেভ করে পরীক্ষা করুন") {
                prefs.apiKey = keyField.text.toString()
                prefs.model = modelField.text.toString()
                result.setTextColor(grey)
                result.text = "পরীক্ষা চলছে…"
                Thread {
                    val err = GeminiClient(prefs).test()
                    runOnUiThread {
                        if (err == null) {
                            result.setTextColor(0xFF1B8A4B.toInt())
                            result.text = "✓ সংযোগ সফল"
                        } else {
                            result.setTextColor(0xFFC62828.toInt())
                            result.text = "✗ $err"
                        }
                    }
                }.start()
            })
            c.addView(result)
        })

        // ভাষা/লেআউট সুইচ
        val enabled = prefs.enabledLayouts.split(",").map { it.trim() }.toMutableSet()
        root.addView(card("টাইপিং পদ্ধতি (একসাথে সুইচ করা যাবে)").also { c ->
            c.addView(text("টিক দেওয়াগুলো ভাষা-বাটন চাপলে বা স্পেসবারে ডানে/বামে সোয়াইপ করলে ঘুরে ঘুরে আসবে।", 13f, grey))
            val names = mapOf(
                "en" to "English (QWERTY)",
                "avro" to "অভ্র (ফোনেটিক — ami → আমি)",
                "jatiya" to "জাতীয়",
                "probhat" to "প্রভাত"
            )
            Layouts.ids.forEach { id ->
                c.addView(CheckBox(this).apply {
                    text = names[id]
                    isChecked = id in enabled
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                    setOnCheckedChangeListener { btn, on ->
                        if (on) enabled.add(id) else enabled.remove(id)
                        if (enabled.isEmpty()) {
                            enabled.add(id)
                            btn.isChecked = true
                        }
                        prefs.enabledLayouts = Layouts.ids.filter { it in enabled }.joinToString(",")
                    }
                })
            }
        })

        // আকার
        val sizeLabel = text("", 14f)
        fun sizeText(p: Int) = "কীবোর্ডের উচ্চতা: $p%"
        sizeLabel.text = sizeText(prefs.heightPct)
        root.addView(card("আকার").also { c ->
            c.addView(sizeLabel)
            c.addView(seek(60, 140, prefs.heightPct) { v ->
                prefs.heightPct = v
                sizeLabel.text = sizeText(v)
            })
            c.addView(toggle("নম্বর সারি দেখাও", prefs.showNumbers) { prefs.showNumbers = it })
            c.addView(toggle("সাজেশন সারি দেখাও", prefs.showSuggestions) { prefs.showSuggestions = it })
        })

        // ভাইব্রেশন ও শব্দ
        val vibLabel = text("", 14f)
        fun vibText(ms: Int) = "ভাইব্রেশনের জোর: ${ms}ms"
        vibLabel.text = vibText(prefs.vibrateMs)
        val volLabel = text("", 14f)
        fun volText(p: Int) = "শব্দের ভলিউম: $p%"
        volLabel.text = volText(prefs.soundVol)
        root.addView(card("ভাইব্রেশন ও টোন").also { c ->
            c.addView(toggle("কী চাপলে ভাইব্রেশন", prefs.vibrate) { prefs.vibrate = it })
            c.addView(vibLabel)
            c.addView(seek(5, 50, prefs.vibrateMs) { v ->
                prefs.vibrateMs = v
                vibLabel.text = vibText(v)
                Feedback(this@MainActivity).apply { vibrateMs = v }.buzz()
            })
            c.addView(text("কী চাপার শব্দ:", 14f).apply { setPadding(0, dp(10), 0, 0) })
            val sound = RadioGroup(this)
            listOf("বন্ধ", "ক্লিক", "বিপ").forEachIndexed { i, label ->
                sound.addView(RadioButton(this).apply {
                    text = label
                    id = 2000 + i
                    isChecked = prefs.soundMode == i
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                })
            }
            sound.setOnCheckedChangeListener { _, checked -> prefs.soundMode = checked - 2000 }
            c.addView(sound)
            c.addView(volLabel)
            c.addView(seek(0, 100, prefs.soundVol) { v ->
                prefs.soundVol = v
                volLabel.text = volText(v)
            })
        })

        // থিম
        themeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fillThemes()
        root.addView(card("থিম").also { c ->
            c.addView(text("কীবোর্ডের 🎨 বাটন চাপলেও থিম বদলায়। সব বাটন একই রঙের, শুধু এন্টার ও সিলেক্টেড বাটনে হাইলাইট রং।", 13f, grey))
            c.addView(HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                setPadding(0, dp(10), 0, 0)
                addView(themeRow)
            })
        })

        // সাজেশন ও আচরণ
        root.addView(card("সাজেশন").also { c ->
            c.addView(toggle("বাংলা/ইংরেজি অভিধান সাজেশন (অফলাইন, তাৎক্ষণিক)", prefs.dictSuggest) { prefs.dictSuggest = it })
            c.addView(toggle("AI শব্দ সাজেশন (Gemini)", prefs.aiEnabled) { prefs.aiEnabled = it })
            c.addView(toggle("স্পেস চাপলে অটো-কারেকশন", prefs.autoCorrect) { prefs.autoCorrect = it })
        })

        // ভয়েস
        micStatus = text("", 14f)
        a11yStatus = text("", 14f)
        root.addView(card("ভয়েস টাইপিং").also { c ->
            c.addView(text(
                "কীবোর্ডের 🎤 চাপলে বলা কথা লেখা হয়। বাংলা মোডে বাংলা, English মোডে ইংরেজি শোনে। " +
                    "(ফোনের Google ভয়েস সার্ভিস ও ইন্টারনেট লাগে)", 13f, grey
            ))
            c.addView(micStatus)
            c.addView(button("মাইক্রোফোনের অনুমতি দিন") {
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            })
        })

        // স্ক্রিন অনুবাদ
        root.addView(card("স্ক্রিন/চ্যাট অনুবাদ (🌐)").also { c ->
            c.addView(text(
                "যেকোনো অ্যাপের চ্যাট বা স্ক্রিন কীবোর্ড থেকেই অনুবাদ, সারাংশ বা উত্তর-সাজেশন করা যায়। " +
                    "এর জন্য Accessibility-তে \"জেমিনি কীবোর্ড স্ক্রিন রিডার\" চালু করতে হবে। " +
                    "এটি শুধু আপনি বাটন চাপলে স্ক্রিনের দৃশ্যমান লেখা পড়ে; পাসওয়ার্ড ও আপনার টাইপ করা ফিল্ড বাদ যায়; কিছু জমায় না।",
                13f, grey
            ))
            c.addView(a11yStatus)
            c.addView(button("Accessibility সেটিংস খুলুন") {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            })
        })
        updateStatuses()

        // ব্যবহার
        root.addView(card("কীভাবে ব্যবহার করবেন").also { c ->
            c.addView(text(
                "😊 ইমোজি  •  📋 ক্লিপবোর্ড (কপি করা লেখা জমা থাকে, 📌 দিলে সেভ)\n" +
                    "✦ AI: ফিল্ডে প্রম্পট লিখে \"লিখে দাও\" চাপলে Gemini লিখে দেয়। ঠিক করো, ছোট/বড়/ফরমাল/ঘরোয়া, ১৫টি ভাষায় অনুবাদ; \"আগেরটা\" দিয়ে ফেরানো যায়।\n" +
                    "💬 চ্যাট: কীবোর্ডের ভেতরেই Gemini-র সাথে কথা বলুন। উত্তরে চাপলে সেটি ফিল্ডে বসবে। \"🖥 স্ক্রিন যোগ\" দিলে চলতি স্ক্রিনের লেখাও Gemini দেখবে।\n" +
                    "🌐 স্ক্রিন: চ্যাট/স্ক্রিন অনুবাদ, সারাংশ ও রিপ্লাই সাজেশন।\n" +
                    "🎤 ভয়েস  •  🎨 থিম বদল  •  ⚙ সেটিংস\n" +
                    "বাংলা কী-তে লং-প্রেস করলে কোণার ছোট অক্ষরটি বসে। স্পেসবারে সোয়াইপ করলে ভাষা বদলায়। " +
                    "জাতীয়/প্রভাতে অ ও বাকি স্বর/কার \"?123 → অআ\" পাতায়।",
                13f, 0xFF4A5163.toInt()
            ))
        })

        // গোপনীয়তা ও কৃতজ্ঞতা
        root.addView(card("গোপনীয়তা ও কৃতজ্ঞতা").also { c ->
            c.addView(
                text(
                    "সাজেশনের জন্য কার্সরের আগের সর্বোচ্চ ৮০ অক্ষর ও বর্তমান শব্দ Gemini API-তে যায়। " +
                        "AI প্যানেলের বাটন চাপলে ফিল্ডের লেখা (সর্বোচ্চ ২০০০ অক্ষর) বা সিলেক্ট করা অংশ পাঠানো হয়। " +
                        "💬 চ্যাট ও 🌐 স্ক্রিন বাটন চাপলে সেই লেখা/স্ক্রিনের লেখা Gemini-তে যায়। " +
                        "পাসওয়ার্ড, ইমেইল, URL ও ইনকগনিটো ফিল্ডে সাজেশন/AI বন্ধ থাকে। " +
                        "ক্লিপবোর্ডের লেখা শুধু ফোনেই থাকে; \"সংবেদনশীল\" চিহ্নিত কপি জমা হয় না।\n\n" +
                        "শব্দভান্ডার: wordfreq প্রকল্পের ডেটা (CC BY-SA 4.0)।",
                    13f, 0xFF4A5163.toInt()
                )
            )
        })

        // টেস্ট ফিল্ড
        root.addView(card("এখানে টাইপ করে দেখুন").also { c ->
            c.addView(field("এখানে লিখুন…", "").apply {
                minLines = 3
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                gravity = Gravity.TOP
            })
        })

        return ScrollView(this).apply {
            setBackgroundColor(bg)
            isFillViewport = true
            addView(root)
        }
    }

    // ---------- থিম বাছাই ----------

    private fun fillThemes() {
        themeRow.removeAllViews()
        val auto = Themes.resolve(this, "auto")
        themeRow.addView(swatch("অটো", auto, prefs.theme == "auto") { pickTheme("auto") })
        Themes.all.forEach { t ->
            themeRow.addView(swatch(t.name, t, prefs.theme == t.id) { pickTheme(t.id) })
        }
    }

    private fun pickTheme(id: String) {
        prefs.theme = id
        fillThemes()
    }

    private fun swatch(name: String, t: Theme, selected: Boolean, onPick: () -> Unit): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(8), dp(8), dp(6))
            background = GradientDrawable().apply {
                setColor(t.bg)
                cornerRadius = dp(12).toFloat()
                setStroke(dp(if (selected) 3 else 1), if (selected) t.accent else 0x44808080)
            }
            layoutParams = LinearLayout.LayoutParams(dp(84), ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { rightMargin = dp(8) }
            setOnClickListener { onPick() }
        }
        val keys = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(t.key, t.key, t.accent).forEach { c ->
            keys.addView(View(this).apply {
                background = GradientDrawable().apply {
                    setColor(c)
                    cornerRadius = dp(4).toFloat()
                }
            }, LinearLayout.LayoutParams(dp(16), dp(16)).apply { setMargins(dp(2), 0, dp(2), 0) })
        }
        box.addView(keys)
        box.addView(TextView(this).apply {
            text = name
            setTextColor(t.text)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, 0)
        })
        return box
    }

    // ---------- UI সহায়ক ----------

    private fun card(title: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(14))
        background = GradientDrawable().apply {
            setColor(Color.WHITE)
            cornerRadius = dp(16).toFloat()
        }
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(12) }
        addView(text(title, 16f, bold = true).apply { setPadding(0, 0, 0, dp(8)) })
    }

    private fun text(s: String, size: Float, color: Int = 0xFF1B1E26.toInt(), bold: Boolean = false) =
        TextView(this).apply {
            text = s
            setTextColor(color)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
            if (bold) setTypeface(null, Typeface.BOLD)
        }

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setTextColor(Color.WHITE)
        background = GradientDrawable().apply {
            setColor(accent)
            cornerRadius = dp(12).toFloat()
        }
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(48)
        ).apply { topMargin = dp(8) }
        setOnClickListener { onClick() }
    }

    private fun field(hint: String, value: String, password: Boolean = false) = EditText(this).apply {
        this.hint = hint
        setText(value)
        inputType = if (password) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        else InputType.TYPE_CLASS_TEXT
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
    }

    private fun toggle(label: String, on: Boolean, onChange: (Boolean) -> Unit) = Switch(this).apply {
        text = label
        isChecked = on
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        setPadding(0, dp(8), 0, dp(8))
        setOnCheckedChangeListener { _, v -> onChange(v) }
    }

    /** lo..hi মানের স্লাইডার */
    private fun seek(lo: Int, hi: Int, value: Int, onChange: (Int) -> Unit) = SeekBar(this).apply {
        max = hi - lo
        progress = (value - lo).coerceIn(0, hi - lo)
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) onChange(lo + progress)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }

    private fun dp(v: Int) =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()
}
