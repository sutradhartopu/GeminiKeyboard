package com.example.geminikeyboard

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

/** সেটিংস ও সেটআপ স্ক্রিন: কীবোর্ড চালু করা, API কী, লেআউট বাছাই। */
class MainActivity : Activity() {

    private val accent = 0xFF4F5EE8.toInt()
    private val bg = 0xFFF3F4F9.toInt()

    private lateinit var prefs: Prefs

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        window.statusBarColor = bg
        setContentView(build())
    }

    private fun build(): ScrollView {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(32))
        }

        root.addView(text("জেমিনি কীবোর্ড", 26f, bold = true))
        root.addView(text("বাংলা ও English • Gemini দিয়ে স্মার্ট সাজেশন ও অটো-কারেকশন", 14f, 0xFF6B7385.toInt()).apply {
            setPadding(0, dp(4), 0, dp(16))
        })

        // ধাপ ১-২
        root.addView(card("ধাপ ১ ও ২ — কীবোর্ড চালু করুন").also { c ->
            c.addView(button("১. কীবোর্ড সক্রিয় করুন") {
                startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
            })
            c.addView(button("২. এই কীবোর্ড বেছে নিন") {
                (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
            })
        })

        // ধাপ ৩: API কী
        val keyField = field("Gemini API কী", prefs.apiKey, password = true)
        val modelField = field("মডেল", prefs.model)
        val result = text("", 13f)
        root.addView(card("ধাপ ৩ — Gemini API").also { c ->
            c.addView(text("aistudio.google.com থেকে বিনামূল্যে কী নিতে পারেন।", 13f, 0xFF6B7385.toInt()))
            c.addView(keyField)
            c.addView(modelField)
            c.addView(button("সেভ করে পরীক্ষা করুন") {
                prefs.apiKey = keyField.text.toString()
                prefs.model = modelField.text.toString()
                result.setTextColor(0xFF6B7385.toInt())
                result.text = "পরীক্ষা চলছে…"
                Thread {
                    val err = GeminiClient(prefs).test()
                    runOnUiThread {
                        if (err == null) {
                            result.setTextColor(0xFF1B8A4B.toInt())
                            result.text = "✓ সংযোগ সফল"
                        } else {
                            result.setTextColor(0xFFC62828.toInt())
                            result.text = "✗ $err"
                        }
                    }
                }.start()
            })
            c.addView(result)
        })

        // বাংলা লেআউট
        val group = RadioGroup(this)
        val options = listOf(
            "avro" to "অভ্র (ফোনেটিক — ami → আমি)",
            "probhat" to "প্রভাত",
            "jatiya" to "জাতীয় (বিজয়-ধাঁচ)"
        )
        options.forEachIndexed { i, (id, label) ->
            group.addView(RadioButton(this).apply {
                text = label
                this.id = 1000 + i
                isChecked = prefs.bnLayout == id
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            })
        }
        group.setOnCheckedChangeListener { _, checkedId ->
            prefs.bnLayout = options[checkedId - 1000].first
        }
        root.addView(card("বাংলা টাইপিং পদ্ধতি").also { it.addView(group) })

        // সুইচ
        root.addView(card("আচরণ").also { c ->
            c.addView(toggle("AI শব্দ সাজেশন", prefs.aiEnabled) { prefs.aiEnabled = it })
            c.addView(toggle("স্পেস চাপলে অটো-কারেকশন", prefs.autoCorrect) { prefs.autoCorrect = it })
            c.addView(toggle("কী চাপলে ভাইব্রেশন", prefs.haptics) { prefs.haptics = it })
        })

        // গোপনীয়তা
        root.addView(card("গোপনীয়তা").also { c ->
            c.addView(
                text(
                    "সাজেশনের জন্য কার্সরের আগের সর্বোচ্চ ৮০ অক্ষর ও বর্তমান শব্দ Gemini API-তে যায়। " +
                        "পাসওয়ার্ড, ইমেইল, URL ও ইনকগনিটো ফিল্ডে কিছুই পাঠানো হয় না। " +
                        "✦ বাটন চাপলে নির্বাচিত বা কার্সরের আগের ৪০০ অক্ষর পর্যন্ত লেখা ঠিক করতে পাঠানো হয়।",
                    13f, 0xFF4A5163.toInt()
                )
            )
        })

        // টেস্ট ফিল্ড
        root.addView(card("এখানে টাইপ করে দেখুন").also { c ->
            c.addView(field("এখানে লিখুন…", "").apply {
                minLines = 3
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                gravity = Gravity.TOP
            })
        })

        return ScrollView(this).apply {
            setBackgroundColor(bg)
            isFillViewport = true
            addView(root)
        }
    }

    // ---------- UI সহায়ক ----------

    private fun card(title: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(14))
        background = GradientDrawable().apply {
            setColor(Color.WHITE)
            cornerRadius = dp(16).toFloat()
        }
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(12) }
        addView(text(title, 16f, bold = true).apply { setPadding(0, 0, 0, dp(8)) })
    }

    private fun text(s: String, size: Float, color: Int = 0xFF1B1E26.toInt(), bold: Boolean = false) =
        TextView(this).apply {
            text = s
            setTextColor(color)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
            if (bold) setTypeface(null, Typeface.BOLD)
        }

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setTextColor(Color.WHITE)
        background = GradientDrawable().apply {
            setColor(accent)
            cornerRadius = dp(12).toFloat()
        }
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(48)
        ).apply { topMargin = dp(8) }
        setOnClickListener { onClick() }
    }

    private fun field(hint: String, value: String, password: Boolean = false) = EditText(this).apply {
        this.hint = hint
        setText(value)
        inputType = if (password) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        else InputType.TYPE_CLASS_TEXT
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
    }

    private fun toggle(label: String, on: Boolean, onChange: (Boolean) -> Unit) = Switch(this).apply {
        text = label
        isChecked = on
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        setPadding(0, dp(8), 0, dp(8))
        setOnCheckedChangeListener { _, v -> onChange(v) }
    }

    private fun dp(v: Int) =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()
}
