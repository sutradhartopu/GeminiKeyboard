package com.example.geminikeyboard

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Gemini REST API ক্লায়েন্ট (ব্লকিং — IO থ্রেডে কল করুন)। */
class GeminiClient(private val prefs: Prefs) {

    data class Suggestions(val correction: String, val words: List<String>)

    @Volatile
    var lastError: String? = null
        private set

    private val cache = object : LinkedHashMap<String, Suggestions>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Suggestions>?) =
            size > 120
    }

    fun suggest(context: String, current: String, rawInput: String, phonetic: Boolean): Suggestions? {
        val key = "$context|$current|$rawInput"
        synchronized(cache) { cache[key]?.let { return it } }

        val prompt = buildString {
            append("You are the prediction engine of a mobile keyboard for Bengali (বাংলা) and English.\n")
            append("Text before the cursor: \"").append(context).append("\"\n")
            append("Word being typed now: \"").append(current).append("\"\n")
            if (phonetic && rawInput.isNotEmpty()) {
                append("The user types Bengali phonetically with Latin letters (Avro style). ")
                append("Raw input: \"").append(rawInput).append("\".\n")
            }
            append("Reply as JSON {\"correction\": string, \"suggestions\": [string, string, string]}.\n")
            append("Rules:\n")
            append("- If the word being typed is empty: correction = \"\" and suggestions = the 3 most likely NEXT words, in the language of the context.\n")
            append("- Otherwise: correction = the correctly spelled version of the word in this context (\"\" if it is already correct); ")
            append("suggestions = 3 likely whole-word completions or alternatives, in the same script as the word being typed.\n")
            append("- Output single words only, no punctuation, no explanations.")
        }
        val schema = JSONObject(
            """{"type":"OBJECT","properties":{"correction":{"type":"STRING"},
               "suggestions":{"type":"ARRAY","items":{"type":"STRING"}}},
               "required":["correction","suggestions"]}"""
        )
        val text = call(prompt, schema, timeoutMs = 4000, maxTokens = 120) ?: return null
        return try {
            val o = JSONObject(text)
            val arr = o.optJSONArray("suggestions") ?: JSONArray()
            val words = (0 until arr.length()).map { arr.optString(it).trim() }.filter { it.isNotEmpty() }
            val res = Suggestions(o.optString("correction").trim(), words)
            synchronized(cache) { cache[key] = res }
            res
        } catch (e: Exception) {
            lastError = e.message
            null
        }
    }

    /** পুরো বাক্যের বানান, ব্যাকরণ ও যতিচিহ্ন ঠিক করে। */
    fun fix(text: String): String? {
        val prompt = "Fix spelling, grammar and punctuation of the text below. " +
            "Keep the same language(s) (Bengali and/or English), meaning, tone, emojis and line breaks. " +
            "Do not translate and do not add anything.\n" +
            "Reply as JSON {\"text\": string}.\n\nText:\n" + text
        val schema = JSONObject(
            """{"type":"OBJECT","properties":{"text":{"type":"STRING"}},"required":["text"]}"""
        )
        val out = call(prompt, schema, timeoutMs = 12000, maxTokens = 1024) ?: return null
        return try {
            JSONObject(out).optString("text").ifBlank { null }
        } catch (e: Exception) {
            lastError = e.message
            null
        }
    }

    /** সেটিংস স্ক্রিনের টেস্ট বাটনের জন্য: সফল হলে null, নইলে ত্রুটির বার্তা। */
    fun test(): String? {
        lastError = null
        val r = suggest("", "আমি", "", false)
        return if (r != null) null else (lastError ?: "অজানা ত্রুটি")
    }

    private fun call(prompt: String, schema: JSONObject, timeoutMs: Int, maxTokens: Int): String? {
        val key = prefs.apiKey
        if (key.isEmpty()) {
            lastError = "API কী দেওয়া হয়নি"
            return null
        }
        val conn = try {
            (URL("https://generativelanguage.googleapis.com/v1beta/models/${prefs.model}:generateContent")
                .openConnection() as HttpURLConnection)
        } catch (e: Exception) {
            lastError = e.message
            return null
        }
        return try {
            conn.requestMethod = "POST"
            conn.connectTimeout = timeoutMs
            conn.readTimeout = timeoutMs
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.setRequestProperty("x-goog-api-key", key)

            val body = JSONObject()
                .put(
                    "contents",
                    JSONArray().put(
                        JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))
                    )
                )
                .put(
                    "generationConfig",
                    JSONObject()
                        .put("temperature", 0.2)
                        .put("maxOutputTokens", maxTokens)
                        .put("responseMimeType", "application/json")
                        .put("responseSchema", schema)
                )
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            if (conn.responseCode !in 200..299) {
                val err = conn.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
                lastError = "HTTP ${conn.responseCode}: " + (runCatching {
                    JSONObject(err).getJSONObject("error").getString("message")
                }.getOrDefault(err.take(160)))
                return null
            }
            val resp = conn.inputStream.bufferedReader().use { it.readText() }
            val text = JSONObject(resp)
                .optJSONArray("candidates")?.optJSONObject(0)
                ?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)
                ?.optString("text")
            if (text.isNullOrBlank()) {
                lastError = "খালি উত্তর"
                null
            } else text
        } catch (e: Exception) {
            lastError = e.message ?: e.javaClass.simpleName
            null
        } finally {
            conn.disconnect()
        }
    }
}
