package com.example.geminikeyboard

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Gemini REST API ক্লায়েন্ট (ব্লকিং — IO থ্রেডে কল করুন)। */
class GeminiClient(private val prefs: Prefs) {

    data class Suggestions(val correction: String, val words: List<String>)

    @Volatile
    var lastError: String? = null
        private set

    private val cache = object : LinkedHashMap<String, Suggestions>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Suggestions>?) =
            size > 120
    }

    private fun textBody(prompt: String): JSONArray = JSONArray().put(
        JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))
    )

    private fun jsonConfig(schema: JSONObject, maxTokens: Int, temp: Double) = JSONObject()
        .put("temperature", temp)
        .put("maxOutputTokens", maxTokens)
        .put("responseMimeType", "application/json")
        .put("responseSchema", schema)

    fun suggest(context: String, current: String, rawInput: String, phonetic: Boolean): Suggestions? {
        val key = "$context|$current|$rawInput"
        synchronized(cache) { cache[key]?.let { return it } }

        val prompt = buildString {
            append("You are the prediction engine of a mobile keyboard for Bengali (বাংলা) and English.\n")
            append("Text before the cursor: \"").append(context).append("\"\n")
            append("Word being typed now: \"").append(current).append("\"\n")
            if (phonetic && rawInput.isNotEmpty()) {
                append("The user types Bengali phonetically with Latin letters (Avro style). ")
                append("Raw input: \"").append(rawInput).append("\".\n")
            }
            append("Reply as JSON {\"correction\": string, \"suggestions\": [string, string, string]}.\n")
            append("Rules:\n")
            append("- If the word being typed is empty: correction = \"\" and suggestions = the 3 most likely NEXT words, in the language of the context.\n")
            append("- Otherwise: correction = the correctly spelled version of the word in this context (\"\" if it is already correct); ")
            append("suggestions = 3 likely whole-word completions or alternatives, in the same script as the word being typed.\n")
            append("- Output single words only, no punctuation, no explanations.")
        }
        val schema = JSONObject(
            """{"type":"OBJECT","properties":{"correction":{"type":"STRING"},
               "suggestions":{"type":"ARRAY","items":{"type":"STRING"}}},
               "required":["correction","suggestions"]}"""
        )
        val body = JSONObject()
            .put("contents", textBody(prompt))
            .put("generationConfig", jsonConfig(schema, 200, 0.2))
        val text = post(body, 4000) ?: return null
        return try {
            val o = JSONObject(text)
            val arr = o.optJSONArray("suggestions") ?: JSONArray()
            val words = (0 until arr.length()).map { arr.optString(it).trim() }.filter { it.isNotEmpty() }
            val res = Suggestions(o.optString("correction").trim(), words)
            synchronized(cache) { cache[key] = res }
            res
        } catch (e: Exception) {
            lastError = e.message
            null
        }
    }

    /**
     * যেকোনো নির্দেশ (লেখা, অনুবাদ, ঠিক করা, সংক্ষেপ…) অনুযায়ী লেখা রূপান্তর।
     * সফল হলে ফলাফল, নইলে null (lastError দেখুন)।
     */
    fun transform(instruction: String, text: String): String? {
        val prompt = instruction +
            "\nReply as JSON {\"text\": string} where text is ONLY the final result, with no preface or explanation." +
            "\n\nText:\n" + text
        val schema = JSONObject(
            """{"type":"OBJECT","properties":{"text":{"type":"STRING"}},"required":["text"]}"""
        )
        val body = JSONObject()
            .put("contents", textBody(prompt))
            .put("generationConfig", jsonConfig(schema, 4096, 0.3))
        val out = post(body, 30000) ?: return null
        return try {
            JSONObject(out).optString("text").ifBlank { null }
        } catch (e: Exception) {
            lastError = e.message
            null
        }
    }

    /** কীবোর্ডের ভেতরের চ্যাট: (fromUser, text) ইতিহাস দিলে পরের উত্তর। */
    fun chat(history: List<Pair<Boolean, String>>): String? {
        val contents = JSONArray()
        history.forEach { (fromUser, text) ->
            contents.put(
                JSONObject()
                    .put("role", if (fromUser) "user" else "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", text)))
            )
        }
        val system = "You are a helpful assistant inside a phone keyboard. Reply in the same language " +
            "the user writes in (Bengali or English). Be concise and ready-to-use: the user may paste " +
            "your answer straight into a chat. Use plain text without markdown symbols."
        val body = JSONObject()
            .put("contents", contents)
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("generationConfig", JSONObject().put("temperature", 0.7).put("maxOutputTokens", 2048))
        return post(body, 40000)
    }

    /** সেটিংস স্ক্রিনের টেস্ট বাটনের জন্য: সফল হলে null, নইলে ত্রুটির বার্তা। */
    fun test(): String? {
        lastError = null
        val r = suggest("", "আমি", "", false)
        return if (r != null) null else (lastError ?: "অজানা ত্রুটি")
    }

    /** body পাঠিয়ে প্রথম candidate-এর লেখা ফেরত দেয় */
    private fun post(body: JSONObject, timeoutMs: Int): String? {
        val key = prefs.apiKey
        if (key.isEmpty()) {
            lastError = "API কী দেওয়া হয়নি"
            return null
        }
        val conn = try {
            (URL("https://generativelanguage.googleapis.com/v1beta/models/${prefs.model}:generateContent")
                .openConnection() as HttpURLConnection)
        } catch (e: Exception) {
            lastError = e.message
            return null
        }
        return try {
            conn.requestMethod = "POST"
            conn.connectTimeout = timeoutMs
            conn.readTimeout = timeoutMs
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.setRequestProperty("x-goog-api-key", key)
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            if (conn.responseCode !in 200..299) {
                val err = conn.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
                lastError = "HTTP ${conn.responseCode}: " + (runCatching {
                    JSONObject(err).getJSONObject("error").getString("message")
                }.getOrDefault(err.take(160)))
                return null
            }
            val resp = conn.inputStream.bufferedReader().use { it.readText() }
            val text = JSONObject(resp)
                .optJSONArray("candidates")?.optJSONObject(0)
                ?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)
                ?.optString("text")
            if (text.isNullOrBlank()) {
                lastError = "খালি উত্তর"
                null
            } else text
        } catch (e: Exception) {
            lastError = e.message ?: e.javaClass.simpleName
            null
        } finally {
            conn.disconnect()
        }
    }
}
