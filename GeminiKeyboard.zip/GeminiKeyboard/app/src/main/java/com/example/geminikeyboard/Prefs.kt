package com.example.geminikeyboard

import android.content.Context
import android.content.SharedPreferences

/** সাধারণ সেটিংস সংরক্ষণ। API কী শুধু এই ডিভাইসেই থাকে। */
class Prefs(context: Context) {
    private val sp = context.applicationContext
        .getSharedPreferences("kb_prefs", Context.MODE_PRIVATE)

    fun listen(l: SharedPreferences.OnSharedPreferenceChangeListener) =
        sp.registerOnSharedPreferenceChangeListener(l)

    fun unlisten(l: SharedPreferences.OnSharedPreferenceChangeListener) =
        sp.unregisterOnSharedPreferenceChangeListener(l)

    var apiKey: String
        get() = sp.getString("api_key", "") ?: ""
        set(v) = sp.edit().putString("api_key", v.trim()).apply()

    var model: String
        get() = sp.getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL
        set(v) = sp.edit().putString("model", v.trim().ifEmpty { DEFAULT_MODEL }).apply()

    /** সুইচে থাকা লেআউট (কমা দিয়ে): en, avro, jatiya, probhat */
    var enabledLayouts: String
        get() = sp.getString("layouts", "en,avro,jatiya,probhat") ?: "en,avro,jatiya,probhat"
        set(v) = sp.edit().putString("layouts", v).apply()

    var curLayout: String
        get() = sp.getString("cur_layout", "en") ?: "en"
        set(v) = sp.edit().putString("cur_layout", v).apply()

    /** "auto" বা Themes.all-এর কোনো id */
    var theme: String
        get() = sp.getString("theme", "auto") ?: "auto"
        set(v) = sp.edit().putString("theme", v).apply()

    var translateTo: String
        get() = sp.getString("translate_to", "English") ?: "English"
        set(v) = sp.edit().putString("translate_to", v).apply()

    var screenLang: String
        get() = sp.getString("screen_lang", "Bengali") ?: "Bengali"
        set(v) = sp.edit().putString("screen_lang", v).apply()

    var recentEmoji: String
        get() = sp.getString("recent_emoji", "") ?: ""
        set(v) = sp.edit().putString("recent_emoji", v).apply()

    /** কীবোর্ডের উচ্চতা, শতাংশ (60..140) */
    var heightPct: Int
        get() = sp.getInt("height_pct", 100)
        set(v) = sp.edit().putInt("height_pct", v.coerceIn(60, 140)).apply()

    var vibrate: Boolean
        get() = sp.getBoolean("vibrate", true)
        set(v) = sp.edit().putBoolean("vibrate", v).apply()

    /** ভাইব্রেশনের দৈর্ঘ্য, মিলিসেকেন্ড (5..50) */
    var vibrateMs: Int
        get() = sp.getInt("vibrate_ms", 18)
        set(v) = sp.edit().putInt("vibrate_ms", v.coerceIn(5, 50)).apply()

    /** 0 বন্ধ, 1 ক্লিক, 2 বিপ */
    var soundMode: Int
        get() = sp.getInt("sound_mode", 0)
        set(v) = sp.edit().putInt("sound_mode", v).apply()

    var soundVol: Int
        get() = sp.getInt("sound_vol", 50)
        set(v) = sp.edit().putInt("sound_vol", v.coerceIn(0, 100)).apply()

    var aiEnabled: Boolean
        get() = sp.getBoolean("ai", true)
        set(v) = sp.edit().putBoolean("ai", v).apply()

    var autoCorrect: Boolean
        get() = sp.getBoolean("autocorrect", true)
        set(v) = sp.edit().putBoolean("autocorrect", v).apply()

    var dictSuggest: Boolean
        get() = sp.getBoolean("dict_suggest", true)
        set(v) = sp.edit().putBoolean("dict_suggest", v).apply()

    var showSuggestions: Boolean
        get() = sp.getBoolean("show_suggestions", true)
        set(v) = sp.edit().putBoolean("show_suggestions", v).apply()

    var showNumbers: Boolean
        get() = sp.getBoolean("show_numbers", true)
        set(v) = sp.edit().putBoolean("show_numbers", v).apply()

    companion object {
        const val DEFAULT_MODEL = "gemini-2.5-flash-lite"

        /** সেটিংসে বদলালে কীবোর্ডে যেগুলোর জন্য রিফ্রেশ দরকার নেই */
        val NO_REFRESH = setOf("recent_emoji", "cur_layout", "translate_to", "screen_lang", "api_key", "model")
    }
}
