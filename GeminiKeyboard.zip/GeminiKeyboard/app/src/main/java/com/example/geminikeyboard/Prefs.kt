package com.example.geminikeyboard

import android.content.Context

/** সাধারণ সেটিংস সংরক্ষণ। API কী শুধু এই ডিভাইসেই থাকে। */
class Prefs(context: Context) {
    private val sp = context.applicationContext
        .getSharedPreferences("kb_prefs", Context.MODE_PRIVATE)

    var apiKey: String
        get() = sp.getString("api_key", "") ?: ""
        set(v) = sp.edit().putString("api_key", v.trim()).apply()

    var model: String
        get() = sp.getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL
        set(v) = sp.edit().putString("model", v.trim().ifEmpty { DEFAULT_MODEL }).apply()

    /** "avro" | "probhat" | "jatiya" */
    var bnLayout: String
        get() = sp.getString("bn_layout", "avro") ?: "avro"
        set(v) = sp.edit().putString("bn_layout", v).apply()

    /** "auto" বা Themes.all-এর কোনো id */
    var theme: String
        get() = sp.getString("theme", "auto") ?: "auto"
        set(v) = sp.edit().putString("theme", v).apply()

    var translateTo: String
        get() = sp.getString("translate_to", "English") ?: "English"
        set(v) = sp.edit().putString("translate_to", v).apply()

    var recentEmoji: String
        get() = sp.getString("recent_emoji", "") ?: ""
        set(v) = sp.edit().putString("recent_emoji", v).apply()

    var aiEnabled: Boolean
        get() = sp.getBoolean("ai", true)
        set(v) = sp.edit().putBoolean("ai", v).apply()

    var autoCorrect: Boolean
        get() = sp.getBoolean("autocorrect", true)
        set(v) = sp.edit().putBoolean("autocorrect", v).apply()

    var haptics: Boolean
        get() = sp.getBoolean("haptics", true)
        set(v) = sp.edit().putBoolean("haptics", v).apply()

    companion object {
        const val DEFAULT_MODEL = "gemini-2.5-flash-lite"
    }
}
